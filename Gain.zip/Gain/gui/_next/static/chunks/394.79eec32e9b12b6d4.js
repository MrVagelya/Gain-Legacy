"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[394],{3121:(e,t,n)=>{let i,r;n.d(t,{l:()=>B});var o=n(5672),s=n(2115),a=n(5269),l=n(9590);let u=new a.NRn,c=new a.Pq0;class f extends a.CmU{constructor(){super(),this.isLineSegmentsGeometry=!0,this.type="LineSegmentsGeometry",this.setIndex([0,2,1,2,3,1,2,4,3,4,5,3,4,6,5,6,7,5]),this.setAttribute("position",new a.qtW([-1,2,0,1,2,0,-1,1,0,1,1,0,-1,0,0,1,0,0,-1,-1,0,1,-1,0],3)),this.setAttribute("uv",new a.qtW([-1,2,1,2,-1,1,1,1,-1,-1,1,-1,-1,-2,1,-2],2))}applyMatrix4(e){let t=this.attributes.instanceStart,n=this.attributes.instanceEnd;return void 0!==t&&(t.applyMatrix4(e),n.applyMatrix4(e),t.needsUpdate=!0),null!==this.boundingBox&&this.computeBoundingBox(),null!==this.boundingSphere&&this.computeBoundingSphere(),this}setPositions(e){let t;e instanceof Float32Array?t=e:Array.isArray(e)&&(t=new Float32Array(e));let n=new a.LuO(t,6,1);return this.setAttribute("instanceStart",new a.eHs(n,3,0)),this.setAttribute("instanceEnd",new a.eHs(n,3,3)),this.computeBoundingBox(),this.computeBoundingSphere(),this}setColors(e,t=3){let n;e instanceof Float32Array?n=e:Array.isArray(e)&&(n=new Float32Array(e));let i=new a.LuO(n,2*t,1);return this.setAttribute("instanceColorStart",new a.eHs(i,t,0)),this.setAttribute("instanceColorEnd",new a.eHs(i,t,t)),this}fromWireframeGeometry(e){return this.setPositions(e.attributes.position.array),this}fromEdgesGeometry(e){return this.setPositions(e.attributes.position.array),this}fromMesh(e){return this.fromWireframeGeometry(new a.XJ7(e.geometry)),this}fromLineSegments(e){let t=e.geometry;return this.setPositions(t.attributes.position.array),this}computeBoundingBox(){null===this.boundingBox&&(this.boundingBox=new a.NRn);let e=this.attributes.instanceStart,t=this.attributes.instanceEnd;void 0!==e&&void 0!==t&&(this.boundingBox.setFromBufferAttribute(e),u.setFromBufferAttribute(t),this.boundingBox.union(u))}computeBoundingSphere(){null===this.boundingSphere&&(this.boundingSphere=new a.iyt),null===this.boundingBox&&this.computeBoundingBox();let e=this.attributes.instanceStart,t=this.attributes.instanceEnd;if(void 0!==e&&void 0!==t){let n=this.boundingSphere.center;this.boundingBox.getCenter(n);let i=0;for(let r=0,o=e.count;r<o;r++)c.fromBufferAttribute(e,r),i=Math.max(i,n.distanceToSquared(c)),c.fromBufferAttribute(t,r),i=Math.max(i,n.distanceToSquared(c));this.boundingSphere.radius=Math.sqrt(i),isNaN(this.boundingSphere.radius)&&console.error("THREE.LineSegmentsGeometry.computeBoundingSphere(): Computed radius is NaN. The instanced position data is likely to have NaN values.",this)}}toJSON(){}applyMatrix(e){return console.warn("THREE.LineSegmentsGeometry: applyMatrix() has been renamed to applyMatrix4()."),this.applyMatrix4(e)}}var d=n(9625);let p=parseInt(a.sPf.replace(/\D+/g,""));class m extends a.BKk{constructor(e){super({type:"LineMaterial",uniforms:a.LlO.clone(a.LlO.merge([d.UniformsLib.common,d.UniformsLib.fog,{worldUnits:{value:1},linewidth:{value:1},resolution:{value:new a.I9Y(1,1)},dashOffset:{value:0},dashScale:{value:1},dashSize:{value:1},gapSize:{value:1}}])),vertexShader:`
				#include <common>
				#include <fog_pars_vertex>
				#include <logdepthbuf_pars_vertex>
				#include <clipping_planes_pars_vertex>

				uniform float linewidth;
				uniform vec2 resolution;

				attribute vec3 instanceStart;
				attribute vec3 instanceEnd;

				#ifdef USE_COLOR
					#ifdef USE_LINE_COLOR_ALPHA
						varying vec4 vLineColor;
						attribute vec4 instanceColorStart;
						attribute vec4 instanceColorEnd;
					#else
						varying vec3 vLineColor;
						attribute vec3 instanceColorStart;
						attribute vec3 instanceColorEnd;
					#endif
				#endif

				#ifdef WORLD_UNITS

					varying vec4 worldPos;
					varying vec3 worldStart;
					varying vec3 worldEnd;

					#ifdef USE_DASH

						varying vec2 vUv;

					#endif

				#else

					varying vec2 vUv;

				#endif

				#ifdef USE_DASH

					uniform float dashScale;
					attribute float instanceDistanceStart;
					attribute float instanceDistanceEnd;
					varying float vLineDistance;

				#endif

				void trimSegment( const in vec4 start, inout vec4 end ) {

					// trim end segment so it terminates between the camera plane and the near plane

					// conservative estimate of the near plane
					float a = projectionMatrix[ 2 ][ 2 ]; // 3nd entry in 3th column
					float b = projectionMatrix[ 3 ][ 2 ]; // 3nd entry in 4th column
					float nearEstimate = - 0.5 * b / a;

					float alpha = ( nearEstimate - start.z ) / ( end.z - start.z );

					end.xyz = mix( start.xyz, end.xyz, alpha );

				}

				void main() {

					#ifdef USE_COLOR

						vLineColor = ( position.y < 0.5 ) ? instanceColorStart : instanceColorEnd;

					#endif

					#ifdef USE_DASH

						vLineDistance = ( position.y < 0.5 ) ? dashScale * instanceDistanceStart : dashScale * instanceDistanceEnd;
						vUv = uv;

					#endif

					float aspect = resolution.x / resolution.y;

					// camera space
					vec4 start = modelViewMatrix * vec4( instanceStart, 1.0 );
					vec4 end = modelViewMatrix * vec4( instanceEnd, 1.0 );

					#ifdef WORLD_UNITS

						worldStart = start.xyz;
						worldEnd = end.xyz;

					#else

						vUv = uv;

					#endif

					// special case for perspective projection, and segments that terminate either in, or behind, the camera plane
					// clearly the gpu firmware has a way of addressing this issue when projecting into ndc space
					// but we need to perform ndc-space calculations in the shader, so we must address this issue directly
					// perhaps there is a more elegant solution -- WestLangley

					bool perspective = ( projectionMatrix[ 2 ][ 3 ] == - 1.0 ); // 4th entry in the 3rd column

					if ( perspective ) {

						if ( start.z < 0.0 && end.z >= 0.0 ) {

							trimSegment( start, end );

						} else if ( end.z < 0.0 && start.z >= 0.0 ) {

							trimSegment( end, start );

						}

					}

					// clip space
					vec4 clipStart = projectionMatrix * start;
					vec4 clipEnd = projectionMatrix * end;

					// ndc space
					vec3 ndcStart = clipStart.xyz / clipStart.w;
					vec3 ndcEnd = clipEnd.xyz / clipEnd.w;

					// direction
					vec2 dir = ndcEnd.xy - ndcStart.xy;

					// account for clip-space aspect ratio
					dir.x *= aspect;
					dir = normalize( dir );

					#ifdef WORLD_UNITS

						// get the offset direction as perpendicular to the view vector
						vec3 worldDir = normalize( end.xyz - start.xyz );
						vec3 offset;
						if ( position.y < 0.5 ) {

							offset = normalize( cross( start.xyz, worldDir ) );

						} else {

							offset = normalize( cross( end.xyz, worldDir ) );

						}

						// sign flip
						if ( position.x < 0.0 ) offset *= - 1.0;

						float forwardOffset = dot( worldDir, vec3( 0.0, 0.0, 1.0 ) );

						// don't extend the line if we're rendering dashes because we
						// won't be rendering the endcaps
						#ifndef USE_DASH

							// extend the line bounds to encompass  endcaps
							start.xyz += - worldDir * linewidth * 0.5;
							end.xyz += worldDir * linewidth * 0.5;

							// shift the position of the quad so it hugs the forward edge of the line
							offset.xy -= dir * forwardOffset;
							offset.z += 0.5;

						#endif

						// endcaps
						if ( position.y > 1.0 || position.y < 0.0 ) {

							offset.xy += dir * 2.0 * forwardOffset;

						}

						// adjust for linewidth
						offset *= linewidth * 0.5;

						// set the world position
						worldPos = ( position.y < 0.5 ) ? start : end;
						worldPos.xyz += offset;

						// project the worldpos
						vec4 clip = projectionMatrix * worldPos;

						// shift the depth of the projected points so the line
						// segments overlap neatly
						vec3 clipPose = ( position.y < 0.5 ) ? ndcStart : ndcEnd;
						clip.z = clipPose.z * clip.w;

					#else

						vec2 offset = vec2( dir.y, - dir.x );
						// undo aspect ratio adjustment
						dir.x /= aspect;
						offset.x /= aspect;

						// sign flip
						if ( position.x < 0.0 ) offset *= - 1.0;

						// endcaps
						if ( position.y < 0.0 ) {

							offset += - dir;

						} else if ( position.y > 1.0 ) {

							offset += dir;

						}

						// adjust for linewidth
						offset *= linewidth;

						// adjust for clip-space to screen-space conversion // maybe resolution should be based on viewport ...
						offset /= resolution.y;

						// select end
						vec4 clip = ( position.y < 0.5 ) ? clipStart : clipEnd;

						// back to clip space
						offset *= clip.w;

						clip.xy += offset;

					#endif

					gl_Position = clip;

					vec4 mvPosition = ( position.y < 0.5 ) ? start : end; // this is an approximation

					#include <logdepthbuf_vertex>
					#include <clipping_planes_vertex>
					#include <fog_vertex>

				}
			`,fragmentShader:`
				uniform vec3 diffuse;
				uniform float opacity;
				uniform float linewidth;

				#ifdef USE_DASH

					uniform float dashOffset;
					uniform float dashSize;
					uniform float gapSize;

				#endif

				varying float vLineDistance;

				#ifdef WORLD_UNITS

					varying vec4 worldPos;
					varying vec3 worldStart;
					varying vec3 worldEnd;

					#ifdef USE_DASH

						varying vec2 vUv;

					#endif

				#else

					varying vec2 vUv;

				#endif

				#include <common>
				#include <fog_pars_fragment>
				#include <logdepthbuf_pars_fragment>
				#include <clipping_planes_pars_fragment>

				#ifdef USE_COLOR
					#ifdef USE_LINE_COLOR_ALPHA
						varying vec4 vLineColor;
					#else
						varying vec3 vLineColor;
					#endif
				#endif

				vec2 closestLineToLine(vec3 p1, vec3 p2, vec3 p3, vec3 p4) {

					float mua;
					float mub;

					vec3 p13 = p1 - p3;
					vec3 p43 = p4 - p3;

					vec3 p21 = p2 - p1;

					float d1343 = dot( p13, p43 );
					float d4321 = dot( p43, p21 );
					float d1321 = dot( p13, p21 );
					float d4343 = dot( p43, p43 );
					float d2121 = dot( p21, p21 );

					float denom = d2121 * d4343 - d4321 * d4321;

					float numer = d1343 * d4321 - d1321 * d4343;

					mua = numer / denom;
					mua = clamp( mua, 0.0, 1.0 );
					mub = ( d1343 + d4321 * ( mua ) ) / d4343;
					mub = clamp( mub, 0.0, 1.0 );

					return vec2( mua, mub );

				}

				void main() {

					#include <clipping_planes_fragment>

					#ifdef USE_DASH

						if ( vUv.y < - 1.0 || vUv.y > 1.0 ) discard; // discard endcaps

						if ( mod( vLineDistance + dashOffset, dashSize + gapSize ) > dashSize ) discard; // todo - FIX

					#endif

					float alpha = opacity;

					#ifdef WORLD_UNITS

						// Find the closest points on the view ray and the line segment
						vec3 rayEnd = normalize( worldPos.xyz ) * 1e5;
						vec3 lineDir = worldEnd - worldStart;
						vec2 params = closestLineToLine( worldStart, worldEnd, vec3( 0.0, 0.0, 0.0 ), rayEnd );

						vec3 p1 = worldStart + lineDir * params.x;
						vec3 p2 = rayEnd * params.y;
						vec3 delta = p1 - p2;
						float len = length( delta );
						float norm = len / linewidth;

						#ifndef USE_DASH

							#ifdef USE_ALPHA_TO_COVERAGE

								float dnorm = fwidth( norm );
								alpha = 1.0 - smoothstep( 0.5 - dnorm, 0.5 + dnorm, norm );

							#else

								if ( norm > 0.5 ) {

									discard;

								}

							#endif

						#endif

					#else

						#ifdef USE_ALPHA_TO_COVERAGE

							// artifacts appear on some hardware if a derivative is taken within a conditional
							float a = vUv.x;
							float b = ( vUv.y > 0.0 ) ? vUv.y - 1.0 : vUv.y + 1.0;
							float len2 = a * a + b * b;
							float dlen = fwidth( len2 );

							if ( abs( vUv.y ) > 1.0 ) {

								alpha = 1.0 - smoothstep( 1.0 - dlen, 1.0 + dlen, len2 );

							}

						#else

							if ( abs( vUv.y ) > 1.0 ) {

								float a = vUv.x;
								float b = ( vUv.y > 0.0 ) ? vUv.y - 1.0 : vUv.y + 1.0;
								float len2 = a * a + b * b;

								if ( len2 > 1.0 ) discard;

							}

						#endif

					#endif

					vec4 diffuseColor = vec4( diffuse, alpha );
					#ifdef USE_COLOR
						#ifdef USE_LINE_COLOR_ALPHA
							diffuseColor *= vLineColor;
						#else
							diffuseColor.rgb *= vLineColor;
						#endif
					#endif

					#include <logdepthbuf_fragment>

					gl_FragColor = diffuseColor;

					#include <tonemapping_fragment>
					#include <${p>=154?"colorspace_fragment":"encodings_fragment"}>
					#include <fog_fragment>
					#include <premultiplied_alpha_fragment>

				}
			`,clipping:!0}),this.isLineMaterial=!0,this.onBeforeCompile=function(){this.transparent?this.defines.USE_LINE_COLOR_ALPHA="1":delete this.defines.USE_LINE_COLOR_ALPHA},Object.defineProperties(this,{color:{enumerable:!0,get:function(){return this.uniforms.diffuse.value},set:function(e){this.uniforms.diffuse.value=e}},worldUnits:{enumerable:!0,get:function(){return"WORLD_UNITS"in this.defines},set:function(e){!0===e?this.defines.WORLD_UNITS="":delete this.defines.WORLD_UNITS}},linewidth:{enumerable:!0,get:function(){return this.uniforms.linewidth.value},set:function(e){this.uniforms.linewidth.value=e}},dashed:{enumerable:!0,get:function(){return"USE_DASH"in this.defines},set(e){!!e!="USE_DASH"in this.defines&&(this.needsUpdate=!0),!0===e?this.defines.USE_DASH="":delete this.defines.USE_DASH}},dashScale:{enumerable:!0,get:function(){return this.uniforms.dashScale.value},set:function(e){this.uniforms.dashScale.value=e}},dashSize:{enumerable:!0,get:function(){return this.uniforms.dashSize.value},set:function(e){this.uniforms.dashSize.value=e}},dashOffset:{enumerable:!0,get:function(){return this.uniforms.dashOffset.value},set:function(e){this.uniforms.dashOffset.value=e}},gapSize:{enumerable:!0,get:function(){return this.uniforms.gapSize.value},set:function(e){this.uniforms.gapSize.value=e}},opacity:{enumerable:!0,get:function(){return this.uniforms.opacity.value},set:function(e){this.uniforms.opacity.value=e}},resolution:{enumerable:!0,get:function(){return this.uniforms.resolution.value},set:function(e){this.uniforms.resolution.value.copy(e)}},alphaToCoverage:{enumerable:!0,get:function(){return"USE_ALPHA_TO_COVERAGE"in this.defines},set:function(e){!!e!="USE_ALPHA_TO_COVERAGE"in this.defines&&(this.needsUpdate=!0),!0===e?(this.defines.USE_ALPHA_TO_COVERAGE="",this.extensions.derivatives=!0):(delete this.defines.USE_ALPHA_TO_COVERAGE,this.extensions.derivatives=!1)}}}),this.setValues(e)}}let v=p>=125?"uv1":"uv2",h=new a.IUQ,y=new a.Pq0,g=new a.Pq0,x=new a.IUQ,w=new a.IUQ,b=new a.IUQ,S=new a.Pq0,U=new a.kn4,E=new a.cZY,P=new a.Pq0,A=new a.NRn,_=new a.iyt,D=new a.IUQ;function z(e,t,n){return D.set(0,0,-t,1).applyMatrix4(e.projectionMatrix),D.multiplyScalar(1/D.w),D.x=r/n.width,D.y=r/n.height,D.applyMatrix4(e.projectionMatrixInverse),D.multiplyScalar(1/D.w),Math.abs(Math.max(D.x,D.y))}class L extends a.eaF{constructor(e=new f,t=new m({color:0xffffff*Math.random()})){super(e,t),this.isLineSegments2=!0,this.type="LineSegments2"}computeLineDistances(){let e=this.geometry,t=e.attributes.instanceStart,n=e.attributes.instanceEnd,i=new Float32Array(2*t.count);for(let e=0,r=0,o=t.count;e<o;e++,r+=2)y.fromBufferAttribute(t,e),g.fromBufferAttribute(n,e),i[r]=0===r?0:i[r-1],i[r+1]=i[r]+y.distanceTo(g);let r=new a.LuO(i,2,1);return e.setAttribute("instanceDistanceStart",new a.eHs(r,1,0)),e.setAttribute("instanceDistanceEnd",new a.eHs(r,1,1)),this}raycast(e,t){let n,o,s=this.material.worldUnits,l=e.camera;null!==l||s||console.error('LineSegments2: "Raycaster.camera" needs to be set in order to raycast against LineSegments2 while worldUnits is set to false.');let u=void 0!==e.params.Line2&&e.params.Line2.threshold||0;i=e.ray;let c=this.matrixWorld,f=this.geometry,d=this.material;if(r=d.linewidth+u,null===f.boundingSphere&&f.computeBoundingSphere(),_.copy(f.boundingSphere).applyMatrix4(c),s)n=.5*r;else{let e=Math.max(l.near,_.distanceToPoint(i.origin));n=z(l,e,d.resolution)}if(_.radius+=n,!1!==i.intersectsSphere(_)){if(null===f.boundingBox&&f.computeBoundingBox(),A.copy(f.boundingBox).applyMatrix4(c),s)o=.5*r;else{let e=Math.max(l.near,A.distanceToPoint(i.origin));o=z(l,e,d.resolution)}A.expandByScalar(o),!1!==i.intersectsBox(A)&&(s?function(e,t){let n=e.matrixWorld,o=e.geometry,s=o.attributes.instanceStart,l=o.attributes.instanceEnd,u=Math.min(o.instanceCount,s.count);for(let o=0;o<u;o++){E.start.fromBufferAttribute(s,o),E.end.fromBufferAttribute(l,o),E.applyMatrix4(n);let u=new a.Pq0,c=new a.Pq0;i.distanceSqToSegment(E.start,E.end,c,u),c.distanceTo(u)<.5*r&&t.push({point:c,pointOnLine:u,distance:i.origin.distanceTo(c),object:e,face:null,faceIndex:o,uv:null,[v]:null})}}(this,t):function(e,t,n){let o=t.projectionMatrix,s=e.material.resolution,l=e.matrixWorld,u=e.geometry,c=u.attributes.instanceStart,f=u.attributes.instanceEnd,d=Math.min(u.instanceCount,c.count),p=-t.near;i.at(1,b),b.w=1,b.applyMatrix4(t.matrixWorldInverse),b.applyMatrix4(o),b.multiplyScalar(1/b.w),b.x*=s.x/2,b.y*=s.y/2,b.z=0,S.copy(b),U.multiplyMatrices(t.matrixWorldInverse,l);for(let t=0;t<d;t++){if(x.fromBufferAttribute(c,t),w.fromBufferAttribute(f,t),x.w=1,w.w=1,x.applyMatrix4(U),w.applyMatrix4(U),x.z>p&&w.z>p)continue;if(x.z>p){let e=x.z-w.z,t=(x.z-p)/e;x.lerp(w,t)}else if(w.z>p){let e=w.z-x.z,t=(w.z-p)/e;w.lerp(x,t)}x.applyMatrix4(o),w.applyMatrix4(o),x.multiplyScalar(1/x.w),w.multiplyScalar(1/w.w),x.x*=s.x/2,x.y*=s.y/2,w.x*=s.x/2,w.y*=s.y/2,E.start.copy(x),E.start.z=0,E.end.copy(w),E.end.z=0;let u=E.closestPointToPointParameter(S,!0);E.at(u,P);let d=a.cj9.lerp(x.z,w.z,u),m=d>=-1&&d<=1,h=S.distanceTo(P)<.5*r;if(m&&h){E.start.fromBufferAttribute(c,t),E.end.fromBufferAttribute(f,t),E.start.applyMatrix4(l),E.end.applyMatrix4(l);let r=new a.Pq0,o=new a.Pq0;i.distanceSqToSegment(E.start,E.end,o,r),n.push({point:o,pointOnLine:r,distance:i.origin.distanceTo(o),object:e,face:null,faceIndex:t,uv:null,[v]:null})}}}(this,l,t))}}onBeforeRender(e){let t=this.material.uniforms;t&&t.resolution&&(e.getViewport(h),this.material.uniforms.resolution.value.set(h.z,h.w))}}class M extends f{constructor(){super(),this.isLineGeometry=!0,this.type="LineGeometry"}setPositions(e){let t=e.length-3,n=new Float32Array(2*t);for(let i=0;i<t;i+=3)n[2*i]=e[i],n[2*i+1]=e[i+1],n[2*i+2]=e[i+2],n[2*i+3]=e[i+3],n[2*i+4]=e[i+4],n[2*i+5]=e[i+5];return super.setPositions(n),this}setColors(e,t=3){let n=e.length-t,i=new Float32Array(2*n);if(3===t)for(let r=0;r<n;r+=t)i[2*r]=e[r],i[2*r+1]=e[r+1],i[2*r+2]=e[r+2],i[2*r+3]=e[r+3],i[2*r+4]=e[r+4],i[2*r+5]=e[r+5];else for(let r=0;r<n;r+=t)i[2*r]=e[r],i[2*r+1]=e[r+1],i[2*r+2]=e[r+2],i[2*r+3]=e[r+3],i[2*r+4]=e[r+4],i[2*r+5]=e[r+5],i[2*r+6]=e[r+6],i[2*r+7]=e[r+7];return super.setColors(i,t),this}fromLine(e){let t=e.geometry;return this.setPositions(t.attributes.position.array),this}}class C extends L{constructor(e=new M,t=new m({color:0xffffff*Math.random()})){super(e,t),this.isLine2=!0,this.type="Line2"}}let O=s.forwardRef(function({points:e,color:t=0xffffff,vertexColors:n,linewidth:i,lineWidth:r,segments:u,dashed:c,...d},p){var v,h;let y=(0,l.C)(e=>e.size),g=s.useMemo(()=>u?new L:new C,[u]),[x]=s.useState(()=>new m),w=(null==n||null==(v=n[0])?void 0:v.length)===4?4:3,b=s.useMemo(()=>{let i=u?new f:new M,r=e.map(e=>{let t=Array.isArray(e);return e instanceof a.Pq0||e instanceof a.IUQ?[e.x,e.y,e.z]:e instanceof a.I9Y?[e.x,e.y,0]:t&&3===e.length?[e[0],e[1],e[2]]:t&&2===e.length?[e[0],e[1],0]:e});if(i.setPositions(r.flat()),n){t=0xffffff;let e=n.map(e=>e instanceof a.Q1f?e.toArray():e);i.setColors(e.flat(),w)}return i},[e,u,n,w]);return s.useLayoutEffect(()=>{g.computeLineDistances()},[e,g]),s.useLayoutEffect(()=>{c?x.defines.USE_DASH="":delete x.defines.USE_DASH,x.needsUpdate=!0},[c,x]),s.useEffect(()=>()=>{b.dispose(),x.dispose()},[b]),s.createElement("primitive",(0,o.A)({object:g,ref:p},d),s.createElement("primitive",{object:b,attach:"geometry"}),s.createElement("primitive",(0,o.A)({object:x,attach:"material",color:t,vertexColors:!!n,resolution:[y.width,y.height],linewidth:null!=(h=null!=i?i:r)?h:1,dashed:c,transparent:4===w},d)))}),B=s.forwardRef(({threshold:e=15,geometry:t,...n},i)=>{let r=s.useRef(null);s.useImperativeHandle(i,()=>r.current,[]);let l=s.useMemo(()=>[0,0,0,1,0,0],[]),u=s.useRef(null),c=s.useRef(null);return s.useLayoutEffect(()=>{let n=r.current.parent,i=null!=t?t:null==n?void 0:n.geometry;if(!i||u.current===i&&c.current===e)return;u.current=i,c.current=e;let o=new a.TDQ(i,e).attributes.position.array;r.current.geometry.setPositions(o),r.current.geometry.attributes.instanceStart.needsUpdate=!0,r.current.geometry.attributes.instanceEnd.needsUpdate=!0,r.current.computeLineDistances()}),s.createElement(O,(0,o.A)({segments:!0,points:l,ref:r,raycast:()=>null},n))})},4184:(e,t,n)=>{n.d(t,{x:()=>p});var i,r,o,s,a=n(5672),l=n(2115),u=n(5269),c=n(9590);let f=parseInt(u.sPf.replace(/\D+/g,"")),d=(i={cellSize:.5,sectionSize:1,fadeDistance:100,fadeStrength:1,fadeFrom:1,cellThickness:.5,sectionThickness:1,cellColor:new u.Q1f,sectionColor:new u.Q1f,infiniteGrid:!1,followCamera:!1,worldCamProjPosition:new u.Pq0,worldPlanePosition:new u.Pq0},r=`
    varying vec3 localPosition;
    varying vec4 worldPosition;

    uniform vec3 worldCamProjPosition;
    uniform vec3 worldPlanePosition;
    uniform float fadeDistance;
    uniform bool infiniteGrid;
    uniform bool followCamera;

    void main() {
      localPosition = position.xzy;
      if (infiniteGrid) localPosition *= 1.0 + fadeDistance;
      
      worldPosition = modelMatrix * vec4(localPosition, 1.0);
      if (followCamera) {
        worldPosition.xyz += (worldCamProjPosition - worldPlanePosition);
        localPosition = (inverse(modelMatrix) * worldPosition).xyz;
      }

      gl_Position = projectionMatrix * viewMatrix * worldPosition;
    }
  `,o=`
    varying vec3 localPosition;
    varying vec4 worldPosition;

    uniform vec3 worldCamProjPosition;
    uniform float cellSize;
    uniform float sectionSize;
    uniform vec3 cellColor;
    uniform vec3 sectionColor;
    uniform float fadeDistance;
    uniform float fadeStrength;
    uniform float fadeFrom;
    uniform float cellThickness;
    uniform float sectionThickness;

    float getGrid(float size, float thickness) {
      vec2 r = localPosition.xz / size;
      vec2 grid = abs(fract(r - 0.5) - 0.5) / fwidth(r);
      float line = min(grid.x, grid.y) + 1.0 - thickness;
      return 1.0 - min(line, 1.0);
    }

    void main() {
      float g1 = getGrid(cellSize, cellThickness);
      float g2 = getGrid(sectionSize, sectionThickness);

      vec3 from = worldCamProjPosition*vec3(fadeFrom);
      float dist = distance(from, worldPosition.xyz);
      float d = 1.0 - min(dist / fadeDistance, 1.0);
      vec3 color = mix(cellColor, sectionColor, min(1.0, sectionThickness * g2));

      gl_FragColor = vec4(color, (g1 + g2) * pow(d, fadeStrength));
      gl_FragColor.a = mix(0.75 * gl_FragColor.a, gl_FragColor.a, g2);
      if (gl_FragColor.a <= 0.0) discard;

      #include <tonemapping_fragment>
      #include <${f>=154?"colorspace_fragment":"encodings_fragment"}>
    }
  `,(s=class extends u.BKk{constructor(e){for(const t in super({vertexShader:r,fragmentShader:o,...e}),i)this.uniforms[t]=new u.nc$(i[t]),Object.defineProperty(this,t,{get(){return this.uniforms[t].value},set(e){this.uniforms[t].value=e}});this.uniforms=u.LlO.clone(this.uniforms)}}).key=u.cj9.generateUUID(),s),p=l.forwardRef(({args:e,cellColor:t="#000000",sectionColor:n="#2080ff",cellSize:i=.5,sectionSize:r=1,followCamera:o=!1,infiniteGrid:s=!1,fadeDistance:f=100,fadeStrength:p=1,fadeFrom:m=1,cellThickness:v=.5,sectionThickness:h=1,side:y=u.hsX,...g},x)=>{(0,c.e)({GridMaterial:d});let w=l.useRef(null);l.useImperativeHandle(x,()=>w.current,[]);let b=new u.Zcv,S=new u.Pq0(0,1,0),U=new u.Pq0(0,0,0);return(0,c.D)(e=>{b.setFromNormalAndCoplanarPoint(S,U).applyMatrix4(w.current.matrixWorld);let t=w.current.material,n=t.uniforms.worldCamProjPosition,i=t.uniforms.worldPlanePosition;b.projectPoint(e.camera.position,n.value),i.value.set(0,0,0).applyMatrix4(w.current.matrixWorld)}),l.createElement("mesh",(0,a.A)({ref:w,frustumCulled:!1},g),l.createElement("gridMaterial",(0,a.A)({transparent:!0,"extensions-derivatives":!0,side:y},{cellSize:i,sectionSize:r,cellColor:t,sectionColor:n,cellThickness:v,sectionThickness:h},{fadeDistance:f,fadeStrength:p,fadeFrom:m,infiniteGrid:s,followCamera:o})),l.createElement("planeGeometry",{args:e}))})},5331:(e,t,n)=>{n.d(t,{C:()=>c});var i=n(5672),r=n(2115),o=n(5269),s=n(9590);class a extends o.LoY{constructor(e,t,n,i){super();const r=[],s=[],a=[],u=new o.Pq0,c=new o.kn4;c.makeRotationFromEuler(n),c.setPosition(t);const f=new o.kn4;function d(t,n,i){n.applyMatrix4(e.matrixWorld),n.applyMatrix4(f),i.transformDirection(e.matrixWorld),t.push(new l(n.clone(),i.clone()))}function p(e,t){let n=[],r=.5*Math.abs(i.dot(t));for(let i=0;i<e.length;i+=3){let o,s,a,l,u,c,f,d=e[i+0].position.dot(t)-r,p=e[i+1].position.dot(t)-r,v=e[i+2].position.dot(t)-r;switch(+!!(u=d>0)+ +!!(c=p>0)+ +!!(f=v>0)){case 0:n.push(e[i]),n.push(e[i+1]),n.push(e[i+2]);break;case 1:if(u&&(o=e[i+1],s=e[i+2],a=m(e[i],o,t,r),l=m(e[i],s,t,r)),c){o=e[i],s=e[i+2],a=m(e[i+1],o,t,r),l=m(e[i+1],s,t,r),n.push(a),n.push(s.clone()),n.push(o.clone()),n.push(s.clone()),n.push(a.clone()),n.push(l);break}f&&(o=e[i],s=e[i+1],a=m(e[i+2],o,t,r),l=m(e[i+2],s,t,r)),n.push(o.clone()),n.push(s.clone()),n.push(a),n.push(l),n.push(a.clone()),n.push(s.clone());break;case 2:u||(s=m(o=e[i].clone(),e[i+1],t,r),a=m(o,e[i+2],t,r),n.push(o),n.push(s),n.push(a)),c||(s=m(o=e[i+1].clone(),e[i+2],t,r),a=m(o,e[i],t,r),n.push(o),n.push(s),n.push(a)),f||(s=m(o=e[i+2].clone(),e[i],t,r),a=m(o,e[i+1],t,r),n.push(o),n.push(s),n.push(a))}}return n}function m(e,t,n,i){let r=e.position.dot(n)-i,s=r/(r-(t.position.dot(n)-i));return new l(new o.Pq0(e.position.x+s*(t.position.x-e.position.x),e.position.y+s*(t.position.y-e.position.y),e.position.z+s*(t.position.z-e.position.z)),new o.Pq0(e.normal.x+s*(t.normal.x-e.normal.x),e.normal.y+s*(t.normal.y-e.normal.y),e.normal.z+s*(t.normal.z-e.normal.z)))}f.copy(c).invert(),function(){let t,n=[],l=new o.Pq0,f=new o.Pq0;if(!0===e.geometry.isGeometry)return console.error("THREE.DecalGeometry no longer supports THREE.Geometry. Use BufferGeometry instead.");let m=e.geometry,v=m.attributes.position,h=m.attributes.normal;if(null!==m.index){let e=m.index;for(t=0;t<e.count;t++)l.fromBufferAttribute(v,e.getX(t)),f.fromBufferAttribute(h,e.getX(t)),d(n,l,f)}else for(t=0;t<v.count;t++)l.fromBufferAttribute(v,t),f.fromBufferAttribute(h,t),d(n,l,f);for(n=p(n,u.set(1,0,0)),n=p(n,u.set(-1,0,0)),n=p(n,u.set(0,1,0)),n=p(n,u.set(0,-1,0)),n=p(n,u.set(0,0,1)),n=p(n,u.set(0,0,-1)),t=0;t<n.length;t++){let e=n[t];a.push(.5+e.position.x/i.x,.5+e.position.y/i.y),e.position.applyMatrix4(c),r.push(e.position.x,e.position.y,e.position.z),s.push(e.normal.x,e.normal.y,e.normal.z)}}(),this.setAttribute("position",new o.qtW(r,3)),this.setAttribute("normal",new o.qtW(s,3)),this.setAttribute("uv",new o.qtW(a,2))}}class l{constructor(e,t){this.position=e,this.normal=t}clone(){return new this.constructor(this.position.clone(),this.normal.clone())}}function u(e=[0,0,0]){return Array.isArray(e)?e:e instanceof o.Pq0||e instanceof o.O9p?[e.x,e.y,e.z]:[e,e,e]}let c=r.forwardRef(function({debug:e,depthTest:t=!1,polygonOffsetFactor:n=-10,map:l,mesh:c,children:f,position:d,rotation:p,scale:m,...v},h){let y=r.useRef(null);r.useImperativeHandle(h,()=>y.current);let g=r.useRef(null),x=r.useRef({position:new o.Pq0,rotation:new o.O9p,scale:new o.Pq0(1,1,1)});return r.useLayoutEffect(()=>{let e=(null==c?void 0:c.current)||y.current.parent,t=y.current;if(!(e instanceof o.eaF))throw Error('Decal must have a Mesh as parent or specify its "mesh" prop');if(e){(0,s.s)(x.current,{position:d,scale:m});let n=e.matrixWorld.clone();if(e.matrixWorld.identity(),p&&"number"!=typeof p)(0,s.s)(x.current,{rotation:p});else{let t=new o.B69;t.position.copy(x.current.position);let n=e.geometry.attributes.position.array;void 0===e.geometry.attributes.normal&&e.geometry.computeVertexNormals();let i=e.geometry.attributes.normal.array,r=1/0,a=new o.Pq0,l=t.position.x,u=t.position.y,c=t.position.z,f=n.length,d=-1;for(let e=0;e<f;e+=3){let t=n[e],i=n[e+1],o=n[e+2],s=t-l,a=i-u,f=o-c,p=s*s+a*a+f*f;p<r&&(r=p,d=e)}a.fromArray(i,d),t.lookAt(t.position.clone().add(a)),t.rotateZ(Math.PI),t.rotateY(Math.PI),"number"==typeof p&&t.rotateZ(p),(0,s.s)(x.current,{rotation:t.rotation})}return g.current&&(0,s.s)(g.current,x.current),t.geometry=new a(e,x.current.position,x.current.rotation,x.current.scale),e.matrixWorld=n,()=>{t.geometry.dispose()}}},[c,...u(d),...u(m),...u(p)]),r.useLayoutEffect(()=>{g.current&&g.current.traverse(e=>e.raycast=()=>null)},[e]),r.createElement("mesh",(0,i.A)({ref:y,"material-transparent":!0,"material-polygonOffset":!0,"material-polygonOffsetFactor":n,"material-depthTest":t,"material-map":l},v),f,e&&r.createElement("mesh",{ref:g},r.createElement("boxGeometry",null),r.createElement("meshNormalMaterial",{wireframe:!0}),r.createElement("axesHelper",null)))})},5359:(e,t,n)=>{n.d(t,{w:()=>r});var i=n(5269);class r extends i.LoY{constructor(e=new i.eaF,t=new i.Pq0,n=new i.O9p,r=new i.Pq0(1,1,1)){super();const s=[],a=[],l=[],u=new i.Pq0,c=new i.dwI().getNormalMatrix(e.matrixWorld),f=new i.kn4;f.makeRotationFromEuler(n),f.setPosition(t);const d=new i.kn4;function p(t,n,i=null){n.applyMatrix4(e.matrixWorld),n.applyMatrix4(d),i?(i.applyNormalMatrix(c),t.push(new o(n.clone(),i.clone()))):t.push(new o(n.clone()))}function m(e,t){let n=[],i=.5*Math.abs(r.dot(t));for(let r=0;r<e.length;r+=3){let o,s,a,l,u=e[r+0].position.dot(t)-i,c=e[r+1].position.dot(t)-i,f=e[r+2].position.dot(t)-i,d=u>0,p=c>0,m=f>0;switch(+!!d+ +!!p+ +!!m){case 0:n.push(e[r]),n.push(e[r+1]),n.push(e[r+2]);break;case 1:if(d&&(o=e[r+1],s=e[r+2],a=v(e[r],o,t,i),l=v(e[r],s,t,i)),p){o=e[r],s=e[r+2],a=v(e[r+1],o,t,i),l=v(e[r+1],s,t,i),n.push(a),n.push(s.clone()),n.push(o.clone()),n.push(s.clone()),n.push(a.clone()),n.push(l);break}m&&(o=e[r],s=e[r+1],a=v(e[r+2],o,t,i),l=v(e[r+2],s,t,i)),n.push(o.clone()),n.push(s.clone()),n.push(a),n.push(l),n.push(a.clone()),n.push(s.clone());break;case 2:d||(s=v(o=e[r].clone(),e[r+1],t,i),a=v(o,e[r+2],t,i),n.push(o),n.push(s),n.push(a)),p||(s=v(o=e[r+1].clone(),e[r+2],t,i),a=v(o,e[r],t,i),n.push(o),n.push(s),n.push(a)),m||(s=v(o=e[r+2].clone(),e[r],t,i),a=v(o,e[r+1],t,i),n.push(o),n.push(s),n.push(a))}}return n}function v(e,t,n,r){let s=e.position.dot(n)-r,a=s/(s-(t.position.dot(n)-r)),l=new i.Pq0(e.position.x+a*(t.position.x-e.position.x),e.position.y+a*(t.position.y-e.position.y),e.position.z+a*(t.position.z-e.position.z)),u=null;return null!==e.normal&&null!==t.normal&&(u=new i.Pq0(e.normal.x+a*(t.normal.x-e.normal.x),e.normal.y+a*(t.normal.y-e.normal.y),e.normal.z+a*(t.normal.z-e.normal.z))),new o(l,u)}d.copy(f).invert(),function(){let t=[],n=new i.Pq0,o=new i.Pq0,c=e.geometry,d=c.attributes.position,v=c.attributes.normal;if(null!==c.index){let e=c.index;for(let i=0;i<e.count;i++)n.fromBufferAttribute(d,e.getX(i)),v?(o.fromBufferAttribute(v,e.getX(i)),p(t,n,o)):p(t,n)}else{if(void 0===d)return;for(let e=0;e<d.count;e++)n.fromBufferAttribute(d,e),v?(o.fromBufferAttribute(v,e),p(t,n,o)):p(t,n)}t=m(t,u.set(1,0,0)),t=m(t,u.set(-1,0,0)),t=m(t,u.set(0,1,0)),t=m(t,u.set(0,-1,0)),t=m(t,u.set(0,0,1)),t=m(t,u.set(0,0,-1));for(let e=0;e<t.length;e++){let n=t[e];l.push(.5+n.position.x/r.x,.5+n.position.y/r.y),n.position.applyMatrix4(f),s.push(n.position.x,n.position.y,n.position.z),null!==n.normal&&a.push(n.normal.x,n.normal.y,n.normal.z)}}(),this.setAttribute("position",new i.qtW(s,3)),this.setAttribute("uv",new i.qtW(l,2)),a.length>0&&this.setAttribute("normal",new i.qtW(a,3))}}class o{constructor(e,t=null){this.position=e,this.normal=t}clone(){let e=this.position.clone(),t=null!==this.normal?this.normal.clone():null;return new this.constructor(e,t)}}},9007:(e,t,n)=>{n.d(t,{_:()=>u});var i=n(5672),r=n(2115),o=n(5269),s=n(9590);let a={uniforms:{tDiffuse:{value:null},h:{value:1/512}},vertexShader:`
      varying vec2 vUv;

      void main() {

        vUv = uv;
        gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

      }
  `,fragmentShader:`
    uniform sampler2D tDiffuse;
    uniform float h;

    varying vec2 vUv;

    void main() {

    	vec4 sum = vec4( 0.0 );

    	sum += texture2D( tDiffuse, vec2( vUv.x - 4.0 * h, vUv.y ) ) * 0.051;
    	sum += texture2D( tDiffuse, vec2( vUv.x - 3.0 * h, vUv.y ) ) * 0.0918;
    	sum += texture2D( tDiffuse, vec2( vUv.x - 2.0 * h, vUv.y ) ) * 0.12245;
    	sum += texture2D( tDiffuse, vec2( vUv.x - 1.0 * h, vUv.y ) ) * 0.1531;
    	sum += texture2D( tDiffuse, vec2( vUv.x, vUv.y ) ) * 0.1633;
    	sum += texture2D( tDiffuse, vec2( vUv.x + 1.0 * h, vUv.y ) ) * 0.1531;
    	sum += texture2D( tDiffuse, vec2( vUv.x + 2.0 * h, vUv.y ) ) * 0.12245;
    	sum += texture2D( tDiffuse, vec2( vUv.x + 3.0 * h, vUv.y ) ) * 0.0918;
    	sum += texture2D( tDiffuse, vec2( vUv.x + 4.0 * h, vUv.y ) ) * 0.051;

    	gl_FragColor = sum;

    }
  `},l={uniforms:{tDiffuse:{value:null},v:{value:1/512}},vertexShader:`
    varying vec2 vUv;

    void main() {

      vUv = uv;
      gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

    }
  `,fragmentShader:`

  uniform sampler2D tDiffuse;
  uniform float v;

  varying vec2 vUv;

  void main() {

    vec4 sum = vec4( 0.0 );

    sum += texture2D( tDiffuse, vec2( vUv.x, vUv.y - 4.0 * v ) ) * 0.051;
    sum += texture2D( tDiffuse, vec2( vUv.x, vUv.y - 3.0 * v ) ) * 0.0918;
    sum += texture2D( tDiffuse, vec2( vUv.x, vUv.y - 2.0 * v ) ) * 0.12245;
    sum += texture2D( tDiffuse, vec2( vUv.x, vUv.y - 1.0 * v ) ) * 0.1531;
    sum += texture2D( tDiffuse, vec2( vUv.x, vUv.y ) ) * 0.1633;
    sum += texture2D( tDiffuse, vec2( vUv.x, vUv.y + 1.0 * v ) ) * 0.1531;
    sum += texture2D( tDiffuse, vec2( vUv.x, vUv.y + 2.0 * v ) ) * 0.12245;
    sum += texture2D( tDiffuse, vec2( vUv.x, vUv.y + 3.0 * v ) ) * 0.0918;
    sum += texture2D( tDiffuse, vec2( vUv.x, vUv.y + 4.0 * v ) ) * 0.051;

    gl_FragColor = sum;

  }
  `},u=r.forwardRef(({scale:e=10,frames:t=1/0,opacity:n=1,width:u=1,height:c=1,blur:f=1,near:d=0,far:p=10,resolution:m=512,smooth:v=!0,color:h="#000000",depthWrite:y=!1,renderOrder:g,...x},w)=>{let b,S,U=r.useRef(null),E=(0,s.C)(e=>e.scene),P=(0,s.C)(e=>e.gl),A=r.useRef(null);u*=Array.isArray(e)?e[0]:e||1,c*=Array.isArray(e)?e[1]:e||1;let[_,D,z,L,M,C,O]=r.useMemo(()=>{let e=new o.nWS(m,m),t=new o.nWS(m,m);t.texture.generateMipmaps=e.texture.generateMipmaps=!1;let n=new o.bdM(u,c).rotateX(Math.PI/2),i=new o.eaF(n),r=new o.CSG;r.depthTest=r.depthWrite=!1,r.onBeforeCompile=e=>{e.uniforms={...e.uniforms,ucolor:{value:new o.Q1f(h)}},e.fragmentShader=e.fragmentShader.replace("void main() {",`uniform vec3 ucolor;
           void main() {
          `),e.fragmentShader=e.fragmentShader.replace("vec4( vec3( 1.0 - fragCoordZ ), opacity );","vec4( ucolor * fragCoordZ * 2.0, ( 1.0 - fragCoordZ ) * 1.0 );")};let s=new o.BKk(a),f=new o.BKk(l);return f.depthTest=s.depthTest=!1,[e,n,r,i,s,f,t]},[m,u,c,e,h]),B=e=>{L.visible=!0,L.material=M,M.uniforms.tDiffuse.value=_.texture,M.uniforms.h.value=e/256,P.setRenderTarget(O),P.render(L,A.current),L.material=C,C.uniforms.tDiffuse.value=O.texture,C.uniforms.v.value=e/256,P.setRenderTarget(_),P.render(L,A.current),L.visible=!1},R=0;return(0,s.D)(()=>{A.current&&(t===1/0||R<t)&&(R++,b=E.background,S=E.overrideMaterial,U.current.visible=!1,E.background=null,E.overrideMaterial=z,P.setRenderTarget(_),P.render(E,A.current),B(f),v&&B(.4*f),P.setRenderTarget(null),U.current.visible=!0,E.overrideMaterial=S,E.background=b)}),r.useImperativeHandle(w,()=>U.current,[]),r.createElement("group",(0,i.A)({"rotation-x":Math.PI/2},x,{ref:U}),r.createElement("mesh",{renderOrder:g,geometry:D,scale:[1,-1,1],rotation:[-Math.PI/2,0,0]},r.createElement("meshBasicMaterial",{transparent:!0,map:_.texture,opacity:n,depthWrite:y})),r.createElement("orthographicCamera",{ref:A,args:[-u/2,u/2,c/2,-c/2,d,p]}))})}}]);