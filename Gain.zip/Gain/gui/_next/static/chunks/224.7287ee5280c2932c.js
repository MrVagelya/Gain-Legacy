"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[224],{916:(e,t,n)=>{n.d(t,{h:()=>l});var r=n(2115),i=n(9339);let o=e=>{let t,n=new Set,r=(e,r)=>{let i="function"==typeof e?e(t):e;if(!Object.is(i,t)){let e=t;t=(null!=r?r:"object"!=typeof i||null===i)?i:Object.assign({},t,i),n.forEach(n=>n(t,e))}},i=()=>t,o={setState:r,getState:i,getInitialState:()=>s,subscribe:e=>(n.add(e),()=>n.delete(e))},s=t=e(r,i,o);return o},{useSyncExternalStoreWithSelector:s}=i,a=(e,t)=>{let n=e?o(e):o,i=(e,i=t)=>(function(e,t=e=>e,n){let i=s(e.subscribe,e.getState,e.getInitialState,t,n);return r.useDebugValue(i),i})(n,e,i);return Object.assign(i,n),i},l=(e,t)=>e?a(e,t):a},3121:(e,t,n)=>{let r,i;n.d(t,{l:()=>T});var o=n(5672),s=n(2115),a=n(5269),l=n(9590);let c=new a.NRn,u=new a.Pq0;class f extends a.CmU{constructor(){super(),this.isLineSegmentsGeometry=!0,this.type="LineSegmentsGeometry",this.setIndex([0,2,1,2,3,1,2,4,3,4,5,3,4,6,5,6,7,5]),this.setAttribute("position",new a.qtW([-1,2,0,1,2,0,-1,1,0,1,1,0,-1,0,0,1,0,0,-1,-1,0,1,-1,0],3)),this.setAttribute("uv",new a.qtW([-1,2,1,2,-1,1,1,1,-1,-1,1,-1,-1,-2,1,-2],2))}applyMatrix4(e){let t=this.attributes.instanceStart,n=this.attributes.instanceEnd;return void 0!==t&&(t.applyMatrix4(e),n.applyMatrix4(e),t.needsUpdate=!0),null!==this.boundingBox&&this.computeBoundingBox(),null!==this.boundingSphere&&this.computeBoundingSphere(),this}setPositions(e){let t;e instanceof Float32Array?t=e:Array.isArray(e)&&(t=new Float32Array(e));let n=new a.LuO(t,6,1);return this.setAttribute("instanceStart",new a.eHs(n,3,0)),this.setAttribute("instanceEnd",new a.eHs(n,3,3)),this.computeBoundingBox(),this.computeBoundingSphere(),this}setColors(e,t=3){let n;e instanceof Float32Array?n=e:Array.isArray(e)&&(n=new Float32Array(e));let r=new a.LuO(n,2*t,1);return this.setAttribute("instanceColorStart",new a.eHs(r,t,0)),this.setAttribute("instanceColorEnd",new a.eHs(r,t,t)),this}fromWireframeGeometry(e){return this.setPositions(e.attributes.position.array),this}fromEdgesGeometry(e){return this.setPositions(e.attributes.position.array),this}fromMesh(e){return this.fromWireframeGeometry(new a.XJ7(e.geometry)),this}fromLineSegments(e){let t=e.geometry;return this.setPositions(t.attributes.position.array),this}computeBoundingBox(){null===this.boundingBox&&(this.boundingBox=new a.NRn);let e=this.attributes.instanceStart,t=this.attributes.instanceEnd;void 0!==e&&void 0!==t&&(this.boundingBox.setFromBufferAttribute(e),c.setFromBufferAttribute(t),this.boundingBox.union(c))}computeBoundingSphere(){null===this.boundingSphere&&(this.boundingSphere=new a.iyt),null===this.boundingBox&&this.computeBoundingBox();let e=this.attributes.instanceStart,t=this.attributes.instanceEnd;if(void 0!==e&&void 0!==t){let n=this.boundingSphere.center;this.boundingBox.getCenter(n);let r=0;for(let i=0,o=e.count;i<o;i++)u.fromBufferAttribute(e,i),r=Math.max(r,n.distanceToSquared(u)),u.fromBufferAttribute(t,i),r=Math.max(r,n.distanceToSquared(u));this.boundingSphere.radius=Math.sqrt(r),isNaN(this.boundingSphere.radius)&&console.error("THREE.LineSegmentsGeometry.computeBoundingSphere(): Computed radius is NaN. The instanced position data is likely to have NaN values.",this)}}toJSON(){}applyMatrix(e){return console.warn("THREE.LineSegmentsGeometry: applyMatrix() has been renamed to applyMatrix4()."),this.applyMatrix4(e)}}var d=n(9625);let p=parseInt(a.sPf.replace(/\D+/g,""));class h extends a.BKk{constructor(e){super({type:"LineMaterial",uniforms:a.LlO.clone(a.LlO.merge([d.UniformsLib.common,d.UniformsLib.fog,{worldUnits:{value:1},linewidth:{value:1},resolution:{value:new a.I9Y(1,1)},dashOffset:{value:0},dashScale:{value:1},dashSize:{value:1},gapSize:{value:1}}])),vertexShader:`
				#include <common>
				#include <fog_pars_vertex>
				#include <logdepthbuf_pars_vertex>
				#include <clipping_planes_pars_vertex>

				uniform float linewidth;
				uniform vec2 resolution;

				attribute vec3 instanceStart;
				attribute vec3 instanceEnd;

				#ifdef USE_COLOR
					#ifdef USE_LINE_COLOR_ALPHA
						varying vec4 vLineColor;
						attribute vec4 instanceColorStart;
						attribute vec4 instanceColorEnd;
					#else
						varying vec3 vLineColor;
						attribute vec3 instanceColorStart;
						attribute vec3 instanceColorEnd;
					#endif
				#endif

				#ifdef WORLD_UNITS

					varying vec4 worldPos;
					varying vec3 worldStart;
					varying vec3 worldEnd;

					#ifdef USE_DASH

						varying vec2 vUv;

					#endif

				#else

					varying vec2 vUv;

				#endif

				#ifdef USE_DASH

					uniform float dashScale;
					attribute float instanceDistanceStart;
					attribute float instanceDistanceEnd;
					varying float vLineDistance;

				#endif

				void trimSegment( const in vec4 start, inout vec4 end ) {

					// trim end segment so it terminates between the camera plane and the near plane

					// conservative estimate of the near plane
					float a = projectionMatrix[ 2 ][ 2 ]; // 3nd entry in 3th column
					float b = projectionMatrix[ 3 ][ 2 ]; // 3nd entry in 4th column
					float nearEstimate = - 0.5 * b / a;

					float alpha = ( nearEstimate - start.z ) / ( end.z - start.z );

					end.xyz = mix( start.xyz, end.xyz, alpha );

				}

				void main() {

					#ifdef USE_COLOR

						vLineColor = ( position.y < 0.5 ) ? instanceColorStart : instanceColorEnd;

					#endif

					#ifdef USE_DASH

						vLineDistance = ( position.y < 0.5 ) ? dashScale * instanceDistanceStart : dashScale * instanceDistanceEnd;
						vUv = uv;

					#endif

					float aspect = resolution.x / resolution.y;

					// camera space
					vec4 start = modelViewMatrix * vec4( instanceStart, 1.0 );
					vec4 end = modelViewMatrix * vec4( instanceEnd, 1.0 );

					#ifdef WORLD_UNITS

						worldStart = start.xyz;
						worldEnd = end.xyz;

					#else

						vUv = uv;

					#endif

					// special case for perspective projection, and segments that terminate either in, or behind, the camera plane
					// clearly the gpu firmware has a way of addressing this issue when projecting into ndc space
					// but we need to perform ndc-space calculations in the shader, so we must address this issue directly
					// perhaps there is a more elegant solution -- WestLangley

					bool perspective = ( projectionMatrix[ 2 ][ 3 ] == - 1.0 ); // 4th entry in the 3rd column

					if ( perspective ) {

						if ( start.z < 0.0 && end.z >= 0.0 ) {

							trimSegment( start, end );

						} else if ( end.z < 0.0 && start.z >= 0.0 ) {

							trimSegment( end, start );

						}

					}

					// clip space
					vec4 clipStart = projectionMatrix * start;
					vec4 clipEnd = projectionMatrix * end;

					// ndc space
					vec3 ndcStart = clipStart.xyz / clipStart.w;
					vec3 ndcEnd = clipEnd.xyz / clipEnd.w;

					// direction
					vec2 dir = ndcEnd.xy - ndcStart.xy;

					// account for clip-space aspect ratio
					dir.x *= aspect;
					dir = normalize( dir );

					#ifdef WORLD_UNITS

						// get the offset direction as perpendicular to the view vector
						vec3 worldDir = normalize( end.xyz - start.xyz );
						vec3 offset;
						if ( position.y < 0.5 ) {

							offset = normalize( cross( start.xyz, worldDir ) );

						} else {

							offset = normalize( cross( end.xyz, worldDir ) );

						}

						// sign flip
						if ( position.x < 0.0 ) offset *= - 1.0;

						float forwardOffset = dot( worldDir, vec3( 0.0, 0.0, 1.0 ) );

						// don't extend the line if we're rendering dashes because we
						// won't be rendering the endcaps
						#ifndef USE_DASH

							// extend the line bounds to encompass  endcaps
							start.xyz += - worldDir * linewidth * 0.5;
							end.xyz += worldDir * linewidth * 0.5;

							// shift the position of the quad so it hugs the forward edge of the line
							offset.xy -= dir * forwardOffset;
							offset.z += 0.5;

						#endif

						// endcaps
						if ( position.y > 1.0 || position.y < 0.0 ) {

							offset.xy += dir * 2.0 * forwardOffset;

						}

						// adjust for linewidth
						offset *= linewidth * 0.5;

						// set the world position
						worldPos = ( position.y < 0.5 ) ? start : end;
						worldPos.xyz += offset;

						// project the worldpos
						vec4 clip = projectionMatrix * worldPos;

						// shift the depth of the projected points so the line
						// segments overlap neatly
						vec3 clipPose = ( position.y < 0.5 ) ? ndcStart : ndcEnd;
						clip.z = clipPose.z * clip.w;

					#else

						vec2 offset = vec2( dir.y, - dir.x );
						// undo aspect ratio adjustment
						dir.x /= aspect;
						offset.x /= aspect;

						// sign flip
						if ( position.x < 0.0 ) offset *= - 1.0;

						// endcaps
						if ( position.y < 0.0 ) {

							offset += - dir;

						} else if ( position.y > 1.0 ) {

							offset += dir;

						}

						// adjust for linewidth
						offset *= linewidth;

						// adjust for clip-space to screen-space conversion // maybe resolution should be based on viewport ...
						offset /= resolution.y;

						// select end
						vec4 clip = ( position.y < 0.5 ) ? clipStart : clipEnd;

						// back to clip space
						offset *= clip.w;

						clip.xy += offset;

					#endif

					gl_Position = clip;

					vec4 mvPosition = ( position.y < 0.5 ) ? start : end; // this is an approximation

					#include <logdepthbuf_vertex>
					#include <clipping_planes_vertex>
					#include <fog_vertex>

				}
			`,fragmentShader:`
				uniform vec3 diffuse;
				uniform float opacity;
				uniform float linewidth;

				#ifdef USE_DASH

					uniform float dashOffset;
					uniform float dashSize;
					uniform float gapSize;

				#endif

				varying float vLineDistance;

				#ifdef WORLD_UNITS

					varying vec4 worldPos;
					varying vec3 worldStart;
					varying vec3 worldEnd;

					#ifdef USE_DASH

						varying vec2 vUv;

					#endif

				#else

					varying vec2 vUv;

				#endif

				#include <common>
				#include <fog_pars_fragment>
				#include <logdepthbuf_pars_fragment>
				#include <clipping_planes_pars_fragment>

				#ifdef USE_COLOR
					#ifdef USE_LINE_COLOR_ALPHA
						varying vec4 vLineColor;
					#else
						varying vec3 vLineColor;
					#endif
				#endif

				vec2 closestLineToLine(vec3 p1, vec3 p2, vec3 p3, vec3 p4) {

					float mua;
					float mub;

					vec3 p13 = p1 - p3;
					vec3 p43 = p4 - p3;

					vec3 p21 = p2 - p1;

					float d1343 = dot( p13, p43 );
					float d4321 = dot( p43, p21 );
					float d1321 = dot( p13, p21 );
					float d4343 = dot( p43, p43 );
					float d2121 = dot( p21, p21 );

					float denom = d2121 * d4343 - d4321 * d4321;

					float numer = d1343 * d4321 - d1321 * d4343;

					mua = numer / denom;
					mua = clamp( mua, 0.0, 1.0 );
					mub = ( d1343 + d4321 * ( mua ) ) / d4343;
					mub = clamp( mub, 0.0, 1.0 );

					return vec2( mua, mub );

				}

				void main() {

					#include <clipping_planes_fragment>

					#ifdef USE_DASH

						if ( vUv.y < - 1.0 || vUv.y > 1.0 ) discard; // discard endcaps

						if ( mod( vLineDistance + dashOffset, dashSize + gapSize ) > dashSize ) discard; // todo - FIX

					#endif

					float alpha = opacity;

					#ifdef WORLD_UNITS

						// Find the closest points on the view ray and the line segment
						vec3 rayEnd = normalize( worldPos.xyz ) * 1e5;
						vec3 lineDir = worldEnd - worldStart;
						vec2 params = closestLineToLine( worldStart, worldEnd, vec3( 0.0, 0.0, 0.0 ), rayEnd );

						vec3 p1 = worldStart + lineDir * params.x;
						vec3 p2 = rayEnd * params.y;
						vec3 delta = p1 - p2;
						float len = length( delta );
						float norm = len / linewidth;

						#ifndef USE_DASH

							#ifdef USE_ALPHA_TO_COVERAGE

								float dnorm = fwidth( norm );
								alpha = 1.0 - smoothstep( 0.5 - dnorm, 0.5 + dnorm, norm );

							#else

								if ( norm > 0.5 ) {

									discard;

								}

							#endif

						#endif

					#else

						#ifdef USE_ALPHA_TO_COVERAGE

							// artifacts appear on some hardware if a derivative is taken within a conditional
							float a = vUv.x;
							float b = ( vUv.y > 0.0 ) ? vUv.y - 1.0 : vUv.y + 1.0;
							float len2 = a * a + b * b;
							float dlen = fwidth( len2 );

							if ( abs( vUv.y ) > 1.0 ) {

								alpha = 1.0 - smoothstep( 1.0 - dlen, 1.0 + dlen, len2 );

							}

						#else

							if ( abs( vUv.y ) > 1.0 ) {

								float a = vUv.x;
								float b = ( vUv.y > 0.0 ) ? vUv.y - 1.0 : vUv.y + 1.0;
								float len2 = a * a + b * b;

								if ( len2 > 1.0 ) discard;

							}

						#endif

					#endif

					vec4 diffuseColor = vec4( diffuse, alpha );
					#ifdef USE_COLOR
						#ifdef USE_LINE_COLOR_ALPHA
							diffuseColor *= vLineColor;
						#else
							diffuseColor.rgb *= vLineColor;
						#endif
					#endif

					#include <logdepthbuf_fragment>

					gl_FragColor = diffuseColor;

					#include <tonemapping_fragment>
					#include <${p>=154?"colorspace_fragment":"encodings_fragment"}>
					#include <fog_fragment>
					#include <premultiplied_alpha_fragment>

				}
			`,clipping:!0}),this.isLineMaterial=!0,this.onBeforeCompile=function(){this.transparent?this.defines.USE_LINE_COLOR_ALPHA="1":delete this.defines.USE_LINE_COLOR_ALPHA},Object.defineProperties(this,{color:{enumerable:!0,get:function(){return this.uniforms.diffuse.value},set:function(e){this.uniforms.diffuse.value=e}},worldUnits:{enumerable:!0,get:function(){return"WORLD_UNITS"in this.defines},set:function(e){!0===e?this.defines.WORLD_UNITS="":delete this.defines.WORLD_UNITS}},linewidth:{enumerable:!0,get:function(){return this.uniforms.linewidth.value},set:function(e){this.uniforms.linewidth.value=e}},dashed:{enumerable:!0,get:function(){return"USE_DASH"in this.defines},set(e){!!e!="USE_DASH"in this.defines&&(this.needsUpdate=!0),!0===e?this.defines.USE_DASH="":delete this.defines.USE_DASH}},dashScale:{enumerable:!0,get:function(){return this.uniforms.dashScale.value},set:function(e){this.uniforms.dashScale.value=e}},dashSize:{enumerable:!0,get:function(){return this.uniforms.dashSize.value},set:function(e){this.uniforms.dashSize.value=e}},dashOffset:{enumerable:!0,get:function(){return this.uniforms.dashOffset.value},set:function(e){this.uniforms.dashOffset.value=e}},gapSize:{enumerable:!0,get:function(){return this.uniforms.gapSize.value},set:function(e){this.uniforms.gapSize.value=e}},opacity:{enumerable:!0,get:function(){return this.uniforms.opacity.value},set:function(e){this.uniforms.opacity.value=e}},resolution:{enumerable:!0,get:function(){return this.uniforms.resolution.value},set:function(e){this.uniforms.resolution.value.copy(e)}},alphaToCoverage:{enumerable:!0,get:function(){return"USE_ALPHA_TO_COVERAGE"in this.defines},set:function(e){!!e!="USE_ALPHA_TO_COVERAGE"in this.defines&&(this.needsUpdate=!0),!0===e?(this.defines.USE_ALPHA_TO_COVERAGE="",this.extensions.derivatives=!0):(delete this.defines.USE_ALPHA_TO_COVERAGE,this.extensions.derivatives=!1)}}}),this.setValues(e)}}let m=p>=125?"uv1":"uv2",v=new a.IUQ,g=new a.Pq0,b=new a.Pq0,y=new a.IUQ,w=new a.IUQ,x=new a.IUQ,E=new a.Pq0,S=new a.kn4,P=new a.cZY,A=new a.Pq0,O=new a.NRn,L=new a.iyt,M=new a.IUQ;function _(e,t,n){return M.set(0,0,-t,1).applyMatrix4(e.projectionMatrix),M.multiplyScalar(1/M.w),M.x=i/n.width,M.y=i/n.height,M.applyMatrix4(e.projectionMatrixInverse),M.multiplyScalar(1/M.w),Math.abs(Math.max(M.x,M.y))}class j extends a.eaF{constructor(e=new f,t=new h({color:0xffffff*Math.random()})){super(e,t),this.isLineSegments2=!0,this.type="LineSegments2"}computeLineDistances(){let e=this.geometry,t=e.attributes.instanceStart,n=e.attributes.instanceEnd,r=new Float32Array(2*t.count);for(let e=0,i=0,o=t.count;e<o;e++,i+=2)g.fromBufferAttribute(t,e),b.fromBufferAttribute(n,e),r[i]=0===i?0:r[i-1],r[i+1]=r[i]+g.distanceTo(b);let i=new a.LuO(r,2,1);return e.setAttribute("instanceDistanceStart",new a.eHs(i,1,0)),e.setAttribute("instanceDistanceEnd",new a.eHs(i,1,1)),this}raycast(e,t){let n,o,s=this.material.worldUnits,l=e.camera;null!==l||s||console.error('LineSegments2: "Raycaster.camera" needs to be set in order to raycast against LineSegments2 while worldUnits is set to false.');let c=void 0!==e.params.Line2&&e.params.Line2.threshold||0;r=e.ray;let u=this.matrixWorld,f=this.geometry,d=this.material;if(i=d.linewidth+c,null===f.boundingSphere&&f.computeBoundingSphere(),L.copy(f.boundingSphere).applyMatrix4(u),s)n=.5*i;else{let e=Math.max(l.near,L.distanceToPoint(r.origin));n=_(l,e,d.resolution)}if(L.radius+=n,!1!==r.intersectsSphere(L)){if(null===f.boundingBox&&f.computeBoundingBox(),O.copy(f.boundingBox).applyMatrix4(u),s)o=.5*i;else{let e=Math.max(l.near,O.distanceToPoint(r.origin));o=_(l,e,d.resolution)}O.expandByScalar(o),!1!==r.intersectsBox(O)&&(s?function(e,t){let n=e.matrixWorld,o=e.geometry,s=o.attributes.instanceStart,l=o.attributes.instanceEnd,c=Math.min(o.instanceCount,s.count);for(let o=0;o<c;o++){P.start.fromBufferAttribute(s,o),P.end.fromBufferAttribute(l,o),P.applyMatrix4(n);let c=new a.Pq0,u=new a.Pq0;r.distanceSqToSegment(P.start,P.end,u,c),u.distanceTo(c)<.5*i&&t.push({point:u,pointOnLine:c,distance:r.origin.distanceTo(u),object:e,face:null,faceIndex:o,uv:null,[m]:null})}}(this,t):function(e,t,n){let o=t.projectionMatrix,s=e.material.resolution,l=e.matrixWorld,c=e.geometry,u=c.attributes.instanceStart,f=c.attributes.instanceEnd,d=Math.min(c.instanceCount,u.count),p=-t.near;r.at(1,x),x.w=1,x.applyMatrix4(t.matrixWorldInverse),x.applyMatrix4(o),x.multiplyScalar(1/x.w),x.x*=s.x/2,x.y*=s.y/2,x.z=0,E.copy(x),S.multiplyMatrices(t.matrixWorldInverse,l);for(let t=0;t<d;t++){if(y.fromBufferAttribute(u,t),w.fromBufferAttribute(f,t),y.w=1,w.w=1,y.applyMatrix4(S),w.applyMatrix4(S),y.z>p&&w.z>p)continue;if(y.z>p){let e=y.z-w.z,t=(y.z-p)/e;y.lerp(w,t)}else if(w.z>p){let e=w.z-y.z,t=(w.z-p)/e;w.lerp(y,t)}y.applyMatrix4(o),w.applyMatrix4(o),y.multiplyScalar(1/y.w),w.multiplyScalar(1/w.w),y.x*=s.x/2,y.y*=s.y/2,w.x*=s.x/2,w.y*=s.y/2,P.start.copy(y),P.start.z=0,P.end.copy(w),P.end.z=0;let c=P.closestPointToPointParameter(E,!0);P.at(c,A);let d=a.cj9.lerp(y.z,w.z,c),h=d>=-1&&d<=1,v=E.distanceTo(A)<.5*i;if(h&&v){P.start.fromBufferAttribute(u,t),P.end.fromBufferAttribute(f,t),P.start.applyMatrix4(l),P.end.applyMatrix4(l);let i=new a.Pq0,o=new a.Pq0;r.distanceSqToSegment(P.start,P.end,o,i),n.push({point:o,pointOnLine:i,distance:r.origin.distanceTo(o),object:e,face:null,faceIndex:t,uv:null,[m]:null})}}}(this,l,t))}}onBeforeRender(e){let t=this.material.uniforms;t&&t.resolution&&(e.getViewport(v),this.material.uniforms.resolution.value.set(v.z,v.w))}}class C extends f{constructor(){super(),this.isLineGeometry=!0,this.type="LineGeometry"}setPositions(e){let t=e.length-3,n=new Float32Array(2*t);for(let r=0;r<t;r+=3)n[2*r]=e[r],n[2*r+1]=e[r+1],n[2*r+2]=e[r+2],n[2*r+3]=e[r+3],n[2*r+4]=e[r+4],n[2*r+5]=e[r+5];return super.setPositions(n),this}setColors(e,t=3){let n=e.length-t,r=new Float32Array(2*n);if(3===t)for(let i=0;i<n;i+=t)r[2*i]=e[i],r[2*i+1]=e[i+1],r[2*i+2]=e[i+2],r[2*i+3]=e[i+3],r[2*i+4]=e[i+4],r[2*i+5]=e[i+5];else for(let i=0;i<n;i+=t)r[2*i]=e[i],r[2*i+1]=e[i+1],r[2*i+2]=e[i+2],r[2*i+3]=e[i+3],r[2*i+4]=e[i+4],r[2*i+5]=e[i+5],r[2*i+6]=e[i+6],r[2*i+7]=e[i+7];return super.setColors(r,t),this}fromLine(e){let t=e.geometry;return this.setPositions(t.attributes.position.array),this}}class z extends j{constructor(e=new C,t=new h({color:0xffffff*Math.random()})){super(e,t),this.isLine2=!0,this.type="Line2"}}let U=s.forwardRef(function({points:e,color:t=0xffffff,vertexColors:n,linewidth:r,lineWidth:i,segments:c,dashed:u,...d},p){var m,v;let g=(0,l.C)(e=>e.size),b=s.useMemo(()=>c?new j:new z,[c]),[y]=s.useState(()=>new h),w=(null==n||null==(m=n[0])?void 0:m.length)===4?4:3,x=s.useMemo(()=>{let r=c?new f:new C,i=e.map(e=>{let t=Array.isArray(e);return e instanceof a.Pq0||e instanceof a.IUQ?[e.x,e.y,e.z]:e instanceof a.I9Y?[e.x,e.y,0]:t&&3===e.length?[e[0],e[1],e[2]]:t&&2===e.length?[e[0],e[1],0]:e});if(r.setPositions(i.flat()),n){t=0xffffff;let e=n.map(e=>e instanceof a.Q1f?e.toArray():e);r.setColors(e.flat(),w)}return r},[e,c,n,w]);return s.useLayoutEffect(()=>{b.computeLineDistances()},[e,b]),s.useLayoutEffect(()=>{u?y.defines.USE_DASH="":delete y.defines.USE_DASH,y.needsUpdate=!0},[u,y]),s.useEffect(()=>()=>{x.dispose(),y.dispose()},[x]),s.createElement("primitive",(0,o.A)({object:b,ref:p},d),s.createElement("primitive",{object:x,attach:"geometry"}),s.createElement("primitive",(0,o.A)({object:y,attach:"material",color:t,vertexColors:!!n,resolution:[g.width,g.height],linewidth:null!=(v=null!=r?r:i)?v:1,dashed:u,transparent:4===w},d)))}),T=s.forwardRef(({threshold:e=15,geometry:t,...n},r)=>{let i=s.useRef(null);s.useImperativeHandle(r,()=>i.current,[]);let l=s.useMemo(()=>[0,0,0,1,0,0],[]),c=s.useRef(null),u=s.useRef(null);return s.useLayoutEffect(()=>{let n=i.current.parent,r=null!=t?t:null==n?void 0:n.geometry;if(!r||c.current===r&&u.current===e)return;c.current=r,u.current=e;let o=new a.TDQ(r,e).attributes.position.array;i.current.geometry.setPositions(o),i.current.geometry.attributes.instanceStart.needsUpdate=!0,i.current.geometry.attributes.instanceEnd.needsUpdate=!0,i.current.computeLineDistances()}),s.createElement(U,(0,o.A)({segments:!0,points:l,ref:i,raycast:()=>null},n))})},4184:(e,t,n)=>{n.d(t,{x:()=>p});var r,i,o,s,a=n(5672),l=n(2115),c=n(5269),u=n(9590);let f=parseInt(c.sPf.replace(/\D+/g,"")),d=(r={cellSize:.5,sectionSize:1,fadeDistance:100,fadeStrength:1,fadeFrom:1,cellThickness:.5,sectionThickness:1,cellColor:new c.Q1f,sectionColor:new c.Q1f,infiniteGrid:!1,followCamera:!1,worldCamProjPosition:new c.Pq0,worldPlanePosition:new c.Pq0},i=`
    varying vec3 localPosition;
    varying vec4 worldPosition;

    uniform vec3 worldCamProjPosition;
    uniform vec3 worldPlanePosition;
    uniform float fadeDistance;
    uniform bool infiniteGrid;
    uniform bool followCamera;

    void main() {
      localPosition = position.xzy;
      if (infiniteGrid) localPosition *= 1.0 + fadeDistance;
      
      worldPosition = modelMatrix * vec4(localPosition, 1.0);
      if (followCamera) {
        worldPosition.xyz += (worldCamProjPosition - worldPlanePosition);
        localPosition = (inverse(modelMatrix) * worldPosition).xyz;
      }

      gl_Position = projectionMatrix * viewMatrix * worldPosition;
    }
  `,o=`
    varying vec3 localPosition;
    varying vec4 worldPosition;

    uniform vec3 worldCamProjPosition;
    uniform float cellSize;
    uniform float sectionSize;
    uniform vec3 cellColor;
    uniform vec3 sectionColor;
    uniform float fadeDistance;
    uniform float fadeStrength;
    uniform float fadeFrom;
    uniform float cellThickness;
    uniform float sectionThickness;

    float getGrid(float size, float thickness) {
      vec2 r = localPosition.xz / size;
      vec2 grid = abs(fract(r - 0.5) - 0.5) / fwidth(r);
      float line = min(grid.x, grid.y) + 1.0 - thickness;
      return 1.0 - min(line, 1.0);
    }

    void main() {
      float g1 = getGrid(cellSize, cellThickness);
      float g2 = getGrid(sectionSize, sectionThickness);

      vec3 from = worldCamProjPosition*vec3(fadeFrom);
      float dist = distance(from, worldPosition.xyz);
      float d = 1.0 - min(dist / fadeDistance, 1.0);
      vec3 color = mix(cellColor, sectionColor, min(1.0, sectionThickness * g2));

      gl_FragColor = vec4(color, (g1 + g2) * pow(d, fadeStrength));
      gl_FragColor.a = mix(0.75 * gl_FragColor.a, gl_FragColor.a, g2);
      if (gl_FragColor.a <= 0.0) discard;

      #include <tonemapping_fragment>
      #include <${f>=154?"colorspace_fragment":"encodings_fragment"}>
    }
  `,(s=class extends c.BKk{constructor(e){for(const t in super({vertexShader:i,fragmentShader:o,...e}),r)this.uniforms[t]=new c.nc$(r[t]),Object.defineProperty(this,t,{get(){return this.uniforms[t].value},set(e){this.uniforms[t].value=e}});this.uniforms=c.LlO.clone(this.uniforms)}}).key=c.cj9.generateUUID(),s),p=l.forwardRef(({args:e,cellColor:t="#000000",sectionColor:n="#2080ff",cellSize:r=.5,sectionSize:i=1,followCamera:o=!1,infiniteGrid:s=!1,fadeDistance:f=100,fadeStrength:p=1,fadeFrom:h=1,cellThickness:m=.5,sectionThickness:v=1,side:g=c.hsX,...b},y)=>{(0,u.e)({GridMaterial:d});let w=l.useRef(null);l.useImperativeHandle(y,()=>w.current,[]);let x=new c.Zcv,E=new c.Pq0(0,1,0),S=new c.Pq0(0,0,0);return(0,u.D)(e=>{x.setFromNormalAndCoplanarPoint(E,S).applyMatrix4(w.current.matrixWorld);let t=w.current.material,n=t.uniforms.worldCamProjPosition,r=t.uniforms.worldPlanePosition;x.projectPoint(e.camera.position,n.value),r.value.set(0,0,0).applyMatrix4(w.current.matrixWorld)}),l.createElement("mesh",(0,a.A)({ref:w,frustumCulled:!1},b),l.createElement("gridMaterial",(0,a.A)({transparent:!0,"extensions-derivatives":!0,side:g},{cellSize:r,sectionSize:i,cellColor:t,sectionColor:n,cellThickness:m,sectionThickness:v},{fadeDistance:f,fadeStrength:p,fadeFrom:h,infiniteGrid:s,followCamera:o})),l.createElement("planeGeometry",{args:e}))})},4400:(e,t,n)=>{n.d(t,{Af:()=>c,Nz:()=>s,u5:()=>u,y3:()=>p});var r,i,o=n(2115);function s(e,t,n){if(!e)return;if(!0===n(e))return e;let r=t?e.return:e.child;for(;r;){let e=s(r,t,n);if(e)return e;r=t?null:r.sibling}}function a(e){try{return Object.defineProperties(e,{_currentRenderer:{get:()=>null,set(){}},_currentRenderer2:{get:()=>null,set(){}}})}catch(t){return e}}"u">typeof window&&((null==(r=window.document)?void 0:r.createElement)||(null==(i=window.navigator)?void 0:i.product)==="ReactNative")?o.useLayoutEffect:o.useEffect;let l=a(o.createContext(null));class c extends o.Component{render(){return o.createElement(l.Provider,{value:this._reactInternals},this.props.children)}}function u(){let e=o.useContext(l);if(null===e)throw Error("its-fine: useFiber must be called within a <FiberProvider />!");let t=o.useId();return o.useMemo(()=>{for(let n of[e,null==e?void 0:e.alternate]){if(!n)continue;let e=s(n,!1,e=>{let n=e.memoizedState;for(;n;){if(n.memoizedState===t)return!0;n=n.next}});if(e)return e}},[e,t])}let f=Symbol.for("react.context"),d=e=>null!==e&&"object"==typeof e&&"$$typeof"in e&&e.$$typeof===f;function p(){let e=function(){let e=u(),[t]=o.useState(()=>new Map);t.clear();let n=e;for(;n;){let e=n.type;d(e)&&e!==l&&!t.has(e)&&t.set(e,o.use(a(e))),n=n.return}return t}();return o.useMemo(()=>Array.from(e.keys()).reduce((t,n)=>r=>o.createElement(t,null,o.createElement(n.Provider,{...r,value:e.get(n)})),e=>o.createElement(c,{...e})),[e])}},5282:(e,t,n)=>{n.d(t,{L:()=>v});var r=n(5269);let i=/^[og]\s*(.+)?/,o=/^mtllib /,s=/^usemtl /,a=/^usemap /,l=/\s+/,c=new r.Pq0,u=new r.Pq0,f=new r.Pq0,d=new r.Pq0,p=new r.Pq0,h=new r.Q1f;function m(){let e={objects:[],object:{},vertices:[],normals:[],colors:[],uvs:[],materials:{},materialLibraries:[],startObject:function(e,t){if(this.object&&!1===this.object.fromDeclaration){this.object.name=e,this.object.fromDeclaration=!1!==t;return}let n=this.object&&"function"==typeof this.object.currentMaterial?this.object.currentMaterial():void 0;if(this.object&&"function"==typeof this.object._finalize&&this.object._finalize(!0),this.object={name:e||"",fromDeclaration:!1!==t,geometry:{vertices:[],normals:[],colors:[],uvs:[],hasUVIndices:!1},materials:[],smooth:!0,startMaterial:function(e,t){let n=this._finalize(!1);n&&(n.inherited||n.groupCount<=0)&&this.materials.splice(n.index,1);let r={index:this.materials.length,name:e||"",mtllib:Array.isArray(t)&&t.length>0?t[t.length-1]:"",smooth:void 0!==n?n.smooth:this.smooth,groupStart:void 0!==n?n.groupEnd:0,groupEnd:-1,groupCount:-1,inherited:!1,clone:function(e){let t={index:"number"==typeof e?e:this.index,name:this.name,mtllib:this.mtllib,smooth:this.smooth,groupStart:0,groupEnd:-1,groupCount:-1,inherited:!1};return t.clone=this.clone.bind(t),t}};return this.materials.push(r),r},currentMaterial:function(){if(this.materials.length>0)return this.materials[this.materials.length-1]},_finalize:function(e){let t=this.currentMaterial();if(t&&-1===t.groupEnd&&(t.groupEnd=this.geometry.vertices.length/3,t.groupCount=t.groupEnd-t.groupStart,t.inherited=!1),e&&this.materials.length>1)for(let e=this.materials.length-1;e>=0;e--)this.materials[e].groupCount<=0&&this.materials.splice(e,1);return e&&0===this.materials.length&&this.materials.push({name:"",smooth:this.smooth}),t}},n&&n.name&&"function"==typeof n.clone){let e=n.clone(0);e.inherited=!0,this.object.materials.push(e)}this.objects.push(this.object)},finalize:function(){this.object&&"function"==typeof this.object._finalize&&this.object._finalize(!0)},parseVertexIndex:function(e,t){let n=parseInt(e,10);return(n>=0?n-1:n+t/3)*3},parseNormalIndex:function(e,t){let n=parseInt(e,10);return(n>=0?n-1:n+t/3)*3},parseUVIndex:function(e,t){let n=parseInt(e,10);return(n>=0?n-1:n+t/2)*2},addVertex:function(e,t,n){let r=this.vertices,i=this.object.geometry.vertices;i.push(r[e+0],r[e+1],r[e+2]),i.push(r[t+0],r[t+1],r[t+2]),i.push(r[n+0],r[n+1],r[n+2])},addVertexPoint:function(e){let t=this.vertices;this.object.geometry.vertices.push(t[e+0],t[e+1],t[e+2])},addVertexLine:function(e){let t=this.vertices;this.object.geometry.vertices.push(t[e+0],t[e+1],t[e+2])},addNormal:function(e,t,n){let r=this.normals,i=this.object.geometry.normals;i.push(r[e+0],r[e+1],r[e+2]),i.push(r[t+0],r[t+1],r[t+2]),i.push(r[n+0],r[n+1],r[n+2])},addFaceNormal:function(e,t,n){let r=this.vertices,i=this.object.geometry.normals;c.fromArray(r,e),u.fromArray(r,t),f.fromArray(r,n),p.subVectors(f,u),d.subVectors(c,u),p.cross(d),p.normalize(),i.push(p.x,p.y,p.z),i.push(p.x,p.y,p.z),i.push(p.x,p.y,p.z)},addColor:function(e,t,n){let r=this.colors,i=this.object.geometry.colors;void 0!==r[e]&&i.push(r[e+0],r[e+1],r[e+2]),void 0!==r[t]&&i.push(r[t+0],r[t+1],r[t+2]),void 0!==r[n]&&i.push(r[n+0],r[n+1],r[n+2])},addUV:function(e,t,n){let r=this.uvs,i=this.object.geometry.uvs;i.push(r[e+0],r[e+1]),i.push(r[t+0],r[t+1]),i.push(r[n+0],r[n+1])},addDefaultUV:function(){let e=this.object.geometry.uvs;e.push(0,0),e.push(0,0),e.push(0,0)},addUVLine:function(e){let t=this.uvs;this.object.geometry.uvs.push(t[e+0],t[e+1])},addFace:function(e,t,n,r,i,o,s,a,l){let c=this.vertices.length,u=this.parseVertexIndex(e,c),f=this.parseVertexIndex(t,c),d=this.parseVertexIndex(n,c);if(this.addVertex(u,f,d),this.addColor(u,f,d),void 0!==s&&""!==s){let e=this.normals.length;u=this.parseNormalIndex(s,e),f=this.parseNormalIndex(a,e),d=this.parseNormalIndex(l,e),this.addNormal(u,f,d)}else this.addFaceNormal(u,f,d);if(void 0!==r&&""!==r){let e=this.uvs.length;u=this.parseUVIndex(r,e),f=this.parseUVIndex(i,e),d=this.parseUVIndex(o,e),this.addUV(u,f,d),this.object.geometry.hasUVIndices=!0}else this.addDefaultUV()},addPointGeometry:function(e){this.object.geometry.type="Points";let t=this.vertices.length;for(let n=0,r=e.length;n<r;n++){let r=this.parseVertexIndex(e[n],t);this.addVertexPoint(r),this.addColor(r)}},addLineGeometry:function(e,t){this.object.geometry.type="Line";let n=this.vertices.length,r=this.uvs.length;for(let t=0,r=e.length;t<r;t++)this.addVertexLine(this.parseVertexIndex(e[t],n));for(let e=0,n=t.length;e<n;e++)this.addUVLine(this.parseUVIndex(t[e],r))}};return e.startObject("",!1),e}class v extends r.aHM{constructor(e){super(e),this.materials=null}load(e,t,n,i){let o=this,s=new r.Y9S(this.manager);s.setPath(this.path),s.setRequestHeader(this.requestHeader),s.setWithCredentials(this.withCredentials),s.load(e,function(n){try{t(o.parse(n))}catch(t){i?i(t):console.error(t),o.manager.itemError(e)}},n,i)}setMaterials(e){return this.materials=e,this}parse(e){let t=new m;-1!==e.indexOf("\r\n")&&(e=e.replace(/\r\n/g,"\n")),-1!==e.indexOf("\\\n")&&(e=e.replace(/\\\n/g,""));let n=e.split("\n"),c=[];for(let e=0,u=n.length;e<u;e++){let u=n[e].trimStart();if(0===u.length)continue;let f=u.charAt(0);if("#"!==f)if("v"===f){let e=u.split(l);switch(e[0]){case"v":t.vertices.push(parseFloat(e[1]),parseFloat(e[2]),parseFloat(e[3])),e.length>=7?(h.setRGB(parseFloat(e[4]),parseFloat(e[5]),parseFloat(e[6]),r.er$),t.colors.push(h.r,h.g,h.b)):t.colors.push(void 0,void 0,void 0);break;case"vn":t.normals.push(parseFloat(e[1]),parseFloat(e[2]),parseFloat(e[3]));break;case"vt":t.uvs.push(parseFloat(e[1]),parseFloat(e[2]))}}else if("f"===f){let e=u.slice(1).trim().split(l),n=[];for(let t=0,r=e.length;t<r;t++){let r=e[t];if(r.length>0){let e=r.split("/");n.push(e)}}let r=n[0];for(let e=1,i=n.length-1;e<i;e++){let i=n[e],o=n[e+1];t.addFace(r[0],i[0],o[0],r[1],i[1],o[1],r[2],i[2],o[2])}}else if("l"===f){let e=u.substring(1).trim().split(" "),n=[],r=[];if(-1===u.indexOf("/"))n=e;else for(let t=0,i=e.length;t<i;t++){let i=e[t].split("/");""!==i[0]&&n.push(i[0]),""!==i[1]&&r.push(i[1])}t.addLineGeometry(n,r)}else if("p"===f){let e=u.slice(1).trim().split(" ");t.addPointGeometry(e)}else if(null!==(c=i.exec(u))){let e=(" "+c[0].slice(1).trim()).slice(1);t.startObject(e)}else if(s.test(u))t.object.startMaterial(u.substring(7).trim(),t.materialLibraries);else if(o.test(u))t.materialLibraries.push(u.substring(7).trim());else if(a.test(u))console.warn('THREE.OBJLoader: Rendering identifier "usemap" not supported. Textures must be defined in MTL files.');else if("s"===f){if((c=u.split(" ")).length>1){let e=c[1].trim().toLowerCase();t.object.smooth="0"!==e&&"off"!==e}else t.object.smooth=!0;let e=t.object.currentMaterial();e&&(e.smooth=t.object.smooth)}else{if("\0"===u)continue;console.warn('THREE.OBJLoader: Unexpected line: "'+u+'"')}}t.finalize();let u=new r.YJl;if(u.materialLibraries=[].concat(t.materialLibraries),!0==(1!==t.objects.length||0!==t.objects[0].geometry.vertices.length))for(let e=0,n=t.objects.length;e<n;e++){let n,i=t.objects[e],o=i.geometry,s=i.materials,a="Line"===o.type,l="Points"===o.type,c=!1;if(0===o.vertices.length)continue;let f=new r.LoY;f.setAttribute("position",new r.qtW(o.vertices,3)),o.normals.length>0&&f.setAttribute("normal",new r.qtW(o.normals,3)),o.colors.length>0&&(c=!0,f.setAttribute("color",new r.qtW(o.colors,3))),!0===o.hasUVIndices&&f.setAttribute("uv",new r.qtW(o.uvs,2));let d=[];for(let e=0,n=s.length;e<n;e++){let n=s[e],i=n.name+"_"+n.smooth+"_"+c,o=t.materials[i];if(null!==this.materials)if(o=this.materials.create(n.name),!a||!o||o instanceof r.mrM){if(l&&o&&!(o instanceof r.BH$)){let e=new r.BH$({size:10,sizeAttenuation:!1});r.imn.prototype.copy.call(e,o),e.color.copy(o.color),e.map=o.map,o=e}}else{let e=new r.mrM;r.imn.prototype.copy.call(e,o),e.color.copy(o.color),o=e}void 0===o&&((o=a?new r.mrM:l?new r.BH$({size:1,sizeAttenuation:!1}):new r.tXL).name=n.name,o.flatShading=!n.smooth,o.vertexColors=c,t.materials[i]=o),d.push(o)}if(d.length>1){for(let e=0,t=s.length;e<t;e++){let t=s[e];f.addGroup(t.groupStart,t.groupCount,e)}n=a?new r.DXC(f,d):l?new r.ONl(f,d):new r.eaF(f,d)}else n=a?new r.DXC(f,d[0]):l?new r.ONl(f,d[0]):new r.eaF(f,d[0]);n.name=i.name,u.add(n)}else if(t.vertices.length>0){let e=new r.BH$({size:1,sizeAttenuation:!1}),n=new r.LoY;n.setAttribute("position",new r.qtW(t.vertices,3)),t.colors.length>0&&void 0!==t.colors[0]&&(n.setAttribute("color",new r.qtW(t.colors,3)),e.vertexColors=!0);let i=new r.ONl(n,e);u.add(i)}return u}}},5331:(e,t,n)=>{n.d(t,{C:()=>u});var r=n(5672),i=n(2115),o=n(5269),s=n(9590);class a extends o.LoY{constructor(e,t,n,r){super();const i=[],s=[],a=[],c=new o.Pq0,u=new o.kn4;u.makeRotationFromEuler(n),u.setPosition(t);const f=new o.kn4;function d(t,n,r){n.applyMatrix4(e.matrixWorld),n.applyMatrix4(f),r.transformDirection(e.matrixWorld),t.push(new l(n.clone(),r.clone()))}function p(e,t){let n=[],i=.5*Math.abs(r.dot(t));for(let r=0;r<e.length;r+=3){let o,s,a,l,c,u,f,d=e[r+0].position.dot(t)-i,p=e[r+1].position.dot(t)-i,m=e[r+2].position.dot(t)-i;switch(+!!(c=d>0)+ +!!(u=p>0)+ +!!(f=m>0)){case 0:n.push(e[r]),n.push(e[r+1]),n.push(e[r+2]);break;case 1:if(c&&(o=e[r+1],s=e[r+2],a=h(e[r],o,t,i),l=h(e[r],s,t,i)),u){o=e[r],s=e[r+2],a=h(e[r+1],o,t,i),l=h(e[r+1],s,t,i),n.push(a),n.push(s.clone()),n.push(o.clone()),n.push(s.clone()),n.push(a.clone()),n.push(l);break}f&&(o=e[r],s=e[r+1],a=h(e[r+2],o,t,i),l=h(e[r+2],s,t,i)),n.push(o.clone()),n.push(s.clone()),n.push(a),n.push(l),n.push(a.clone()),n.push(s.clone());break;case 2:c||(s=h(o=e[r].clone(),e[r+1],t,i),a=h(o,e[r+2],t,i),n.push(o),n.push(s),n.push(a)),u||(s=h(o=e[r+1].clone(),e[r+2],t,i),a=h(o,e[r],t,i),n.push(o),n.push(s),n.push(a)),f||(s=h(o=e[r+2].clone(),e[r],t,i),a=h(o,e[r+1],t,i),n.push(o),n.push(s),n.push(a))}}return n}function h(e,t,n,r){let i=e.position.dot(n)-r,s=i/(i-(t.position.dot(n)-r));return new l(new o.Pq0(e.position.x+s*(t.position.x-e.position.x),e.position.y+s*(t.position.y-e.position.y),e.position.z+s*(t.position.z-e.position.z)),new o.Pq0(e.normal.x+s*(t.normal.x-e.normal.x),e.normal.y+s*(t.normal.y-e.normal.y),e.normal.z+s*(t.normal.z-e.normal.z)))}f.copy(u).invert(),function(){let t,n=[],l=new o.Pq0,f=new o.Pq0;if(!0===e.geometry.isGeometry)return console.error("THREE.DecalGeometry no longer supports THREE.Geometry. Use BufferGeometry instead.");let h=e.geometry,m=h.attributes.position,v=h.attributes.normal;if(null!==h.index){let e=h.index;for(t=0;t<e.count;t++)l.fromBufferAttribute(m,e.getX(t)),f.fromBufferAttribute(v,e.getX(t)),d(n,l,f)}else for(t=0;t<m.count;t++)l.fromBufferAttribute(m,t),f.fromBufferAttribute(v,t),d(n,l,f);for(n=p(n,c.set(1,0,0)),n=p(n,c.set(-1,0,0)),n=p(n,c.set(0,1,0)),n=p(n,c.set(0,-1,0)),n=p(n,c.set(0,0,1)),n=p(n,c.set(0,0,-1)),t=0;t<n.length;t++){let e=n[t];a.push(.5+e.position.x/r.x,.5+e.position.y/r.y),e.position.applyMatrix4(u),i.push(e.position.x,e.position.y,e.position.z),s.push(e.normal.x,e.normal.y,e.normal.z)}}(),this.setAttribute("position",new o.qtW(i,3)),this.setAttribute("normal",new o.qtW(s,3)),this.setAttribute("uv",new o.qtW(a,2))}}class l{constructor(e,t){this.position=e,this.normal=t}clone(){return new this.constructor(this.position.clone(),this.normal.clone())}}function c(e=[0,0,0]){return Array.isArray(e)?e:e instanceof o.Pq0||e instanceof o.O9p?[e.x,e.y,e.z]:[e,e,e]}let u=i.forwardRef(function({debug:e,depthTest:t=!1,polygonOffsetFactor:n=-10,map:l,mesh:u,children:f,position:d,rotation:p,scale:h,...m},v){let g=i.useRef(null);i.useImperativeHandle(v,()=>g.current);let b=i.useRef(null),y=i.useRef({position:new o.Pq0,rotation:new o.O9p,scale:new o.Pq0(1,1,1)});return i.useLayoutEffect(()=>{let e=(null==u?void 0:u.current)||g.current.parent,t=g.current;if(!(e instanceof o.eaF))throw Error('Decal must have a Mesh as parent or specify its "mesh" prop');if(e){(0,s.s)(y.current,{position:d,scale:h});let n=e.matrixWorld.clone();if(e.matrixWorld.identity(),p&&"number"!=typeof p)(0,s.s)(y.current,{rotation:p});else{let t=new o.B69;t.position.copy(y.current.position);let n=e.geometry.attributes.position.array;void 0===e.geometry.attributes.normal&&e.geometry.computeVertexNormals();let r=e.geometry.attributes.normal.array,i=1/0,a=new o.Pq0,l=t.position.x,c=t.position.y,u=t.position.z,f=n.length,d=-1;for(let e=0;e<f;e+=3){let t=n[e],r=n[e+1],o=n[e+2],s=t-l,a=r-c,f=o-u,p=s*s+a*a+f*f;p<i&&(i=p,d=e)}a.fromArray(r,d),t.lookAt(t.position.clone().add(a)),t.rotateZ(Math.PI),t.rotateY(Math.PI),"number"==typeof p&&t.rotateZ(p),(0,s.s)(y.current,{rotation:t.rotation})}return b.current&&(0,s.s)(b.current,y.current),t.geometry=new a(e,y.current.position,y.current.rotation,y.current.scale),e.matrixWorld=n,()=>{t.geometry.dispose()}}},[u,...c(d),...c(h),...c(p)]),i.useLayoutEffect(()=>{b.current&&b.current.traverse(e=>e.raycast=()=>null)},[e]),i.createElement("mesh",(0,r.A)({ref:g,"material-transparent":!0,"material-polygonOffset":!0,"material-polygonOffsetFactor":n,"material-depthTest":t,"material-map":l},m),f,e&&i.createElement("mesh",{ref:b},i.createElement("boxGeometry",null),i.createElement("meshNormalMaterial",{wireframe:!0}),i.createElement("axesHelper",null)))})},5359:(e,t,n)=>{n.d(t,{w:()=>i});var r=n(5269);class i extends r.LoY{constructor(e=new r.eaF,t=new r.Pq0,n=new r.O9p,i=new r.Pq0(1,1,1)){super();const s=[],a=[],l=[],c=new r.Pq0,u=new r.dwI().getNormalMatrix(e.matrixWorld),f=new r.kn4;f.makeRotationFromEuler(n),f.setPosition(t);const d=new r.kn4;function p(t,n,r=null){n.applyMatrix4(e.matrixWorld),n.applyMatrix4(d),r?(r.applyNormalMatrix(u),t.push(new o(n.clone(),r.clone()))):t.push(new o(n.clone()))}function h(e,t){let n=[],r=.5*Math.abs(i.dot(t));for(let i=0;i<e.length;i+=3){let o,s,a,l,c=e[i+0].position.dot(t)-r,u=e[i+1].position.dot(t)-r,f=e[i+2].position.dot(t)-r,d=c>0,p=u>0,h=f>0;switch(+!!d+ +!!p+ +!!h){case 0:n.push(e[i]),n.push(e[i+1]),n.push(e[i+2]);break;case 1:if(d&&(o=e[i+1],s=e[i+2],a=m(e[i],o,t,r),l=m(e[i],s,t,r)),p){o=e[i],s=e[i+2],a=m(e[i+1],o,t,r),l=m(e[i+1],s,t,r),n.push(a),n.push(s.clone()),n.push(o.clone()),n.push(s.clone()),n.push(a.clone()),n.push(l);break}h&&(o=e[i],s=e[i+1],a=m(e[i+2],o,t,r),l=m(e[i+2],s,t,r)),n.push(o.clone()),n.push(s.clone()),n.push(a),n.push(l),n.push(a.clone()),n.push(s.clone());break;case 2:d||(s=m(o=e[i].clone(),e[i+1],t,r),a=m(o,e[i+2],t,r),n.push(o),n.push(s),n.push(a)),p||(s=m(o=e[i+1].clone(),e[i+2],t,r),a=m(o,e[i],t,r),n.push(o),n.push(s),n.push(a)),h||(s=m(o=e[i+2].clone(),e[i],t,r),a=m(o,e[i+1],t,r),n.push(o),n.push(s),n.push(a))}}return n}function m(e,t,n,i){let s=e.position.dot(n)-i,a=s/(s-(t.position.dot(n)-i)),l=new r.Pq0(e.position.x+a*(t.position.x-e.position.x),e.position.y+a*(t.position.y-e.position.y),e.position.z+a*(t.position.z-e.position.z)),c=null;return null!==e.normal&&null!==t.normal&&(c=new r.Pq0(e.normal.x+a*(t.normal.x-e.normal.x),e.normal.y+a*(t.normal.y-e.normal.y),e.normal.z+a*(t.normal.z-e.normal.z))),new o(l,c)}d.copy(f).invert(),function(){let t=[],n=new r.Pq0,o=new r.Pq0,u=e.geometry,d=u.attributes.position,m=u.attributes.normal;if(null!==u.index){let e=u.index;for(let r=0;r<e.count;r++)n.fromBufferAttribute(d,e.getX(r)),m?(o.fromBufferAttribute(m,e.getX(r)),p(t,n,o)):p(t,n)}else{if(void 0===d)return;for(let e=0;e<d.count;e++)n.fromBufferAttribute(d,e),m?(o.fromBufferAttribute(m,e),p(t,n,o)):p(t,n)}t=h(t,c.set(1,0,0)),t=h(t,c.set(-1,0,0)),t=h(t,c.set(0,1,0)),t=h(t,c.set(0,-1,0)),t=h(t,c.set(0,0,1)),t=h(t,c.set(0,0,-1));for(let e=0;e<t.length;e++){let n=t[e];l.push(.5+n.position.x/i.x,.5+n.position.y/i.y),n.position.applyMatrix4(f),s.push(n.position.x,n.position.y,n.position.z),null!==n.normal&&a.push(n.normal.x,n.normal.y,n.normal.z)}}(),this.setAttribute("position",new r.qtW(s,3)),this.setAttribute("uv",new r.qtW(l,2)),a.length>0&&this.setAttribute("normal",new r.qtW(a,3))}}class o{constructor(e,t=null){this.position=e,this.normal=t}clone(){let e=this.position.clone(),t=null!==this.normal?this.normal.clone():null;return new this.constructor(e,t)}}},5538:(e,t,n)=>{var r=n(2115),i="function"==typeof Object.is?Object.is:function(e,t){return e===t&&(0!==e||1/e==1/t)||e!=e&&t!=t},o=r.useState,s=r.useEffect,a=r.useLayoutEffect,l=r.useDebugValue;function c(e){var t=e.getSnapshot;e=e.value;try{var n=t();return!i(e,n)}catch(e){return!0}}var u="u"<typeof window||void 0===window.document||void 0===window.document.createElement?function(e,t){return t()}:function(e,t){var n=t(),r=o({inst:{value:n,getSnapshot:t}}),i=r[0].inst,u=r[1];return a(function(){i.value=n,i.getSnapshot=t,c(i)&&u({inst:i})},[e,n,t]),s(function(){return c(i)&&u({inst:i}),e(function(){c(i)&&u({inst:i})})},[e]),l(n),n};t.useSyncExternalStore=void 0!==r.useSyncExternalStore?r.useSyncExternalStore:u},5672:(e,t,n)=>{n.d(t,{A:()=>r});function r(){return(r=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)({}).hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e}).apply(null,arguments)}},6275:(e,t,n)=>{n.d(t,{Hl:()=>f});var r=n(9590),i=n(2115),o=n(9625);function s(e,t){let n;return(...r)=>{window.clearTimeout(n),n=window.setTimeout(()=>e(...r),t)}}let a=["x","y","top","bottom","left","right","width","height"];var l=n(4400),c=n(5155);function u({ref:e,children:t,fallback:n,resize:l,style:f,gl:d,events:p=r.f,eventSource:h,eventPrefix:m,shadows:v,linear:g,flat:b,legacy:y,orthographic:w,frameloop:x,dpr:E,performance:S,raycaster:P,camera:A,scene:O,onPointerMissed:L,onCreated:M,..._}){i.useMemo(()=>(0,r.e)(o),[]);let j=(0,r.u)(),[C,z]=function({debounce:e,scroll:t,polyfill:n,offsetSize:r}={debounce:0,scroll:!1,offsetSize:!1}){var o,l,c;let u=n||("u"<typeof window?class{}:window.ResizeObserver);if(!u)throw Error("This browser does not support ResizeObserver out of the box. See: https://github.com/react-spring/react-use-measure/#resize-observer-polyfills");let[f,d]=(0,i.useState)({left:0,top:0,width:0,height:0,bottom:0,right:0,x:0,y:0}),p=(0,i.useRef)({element:null,scrollContainers:null,resizeObserver:null,lastBounds:f,orientationHandler:null}),h=e?"number"==typeof e?e:e.scroll:null,m=e?"number"==typeof e?e:e.resize:null,v=(0,i.useRef)(!1);(0,i.useEffect)(()=>(v.current=!0,()=>void(v.current=!1)));let[g,b,y]=(0,i.useMemo)(()=>{let e=()=>{let e,t;if(!p.current.element)return;let{left:n,top:i,width:o,height:s,bottom:l,right:c,x:u,y:f}=p.current.element.getBoundingClientRect(),h={left:n,top:i,width:o,height:s,bottom:l,right:c,x:u,y:f};p.current.element instanceof HTMLElement&&r&&(h.height=p.current.element.offsetHeight,h.width=p.current.element.offsetWidth),Object.freeze(h),v.current&&(e=p.current.lastBounds,t=h,!a.every(n=>e[n]===t[n]))&&d(p.current.lastBounds=h)};return[e,m?s(e,m):e,h?s(e,h):e]},[d,r,h,m]);function w(){p.current.scrollContainers&&(p.current.scrollContainers.forEach(e=>e.removeEventListener("scroll",y,!0)),p.current.scrollContainers=null),p.current.resizeObserver&&(p.current.resizeObserver.disconnect(),p.current.resizeObserver=null),p.current.orientationHandler&&("orientation"in screen&&"removeEventListener"in screen.orientation?screen.orientation.removeEventListener("change",p.current.orientationHandler):"onorientationchange"in window&&window.removeEventListener("orientationchange",p.current.orientationHandler))}function x(){p.current.element&&(p.current.resizeObserver=new u(y),p.current.resizeObserver.observe(p.current.element),t&&p.current.scrollContainers&&p.current.scrollContainers.forEach(e=>e.addEventListener("scroll",y,{capture:!0,passive:!0})),p.current.orientationHandler=()=>{y()},"orientation"in screen&&"addEventListener"in screen.orientation?screen.orientation.addEventListener("change",p.current.orientationHandler):"onorientationchange"in window&&window.addEventListener("orientationchange",p.current.orientationHandler))}return o=y,l=!!t,(0,i.useEffect)(()=>{if(l)return window.addEventListener("scroll",o,{capture:!0,passive:!0}),()=>void window.removeEventListener("scroll",o,!0)},[o,l]),c=b,(0,i.useEffect)(()=>(window.addEventListener("resize",c),()=>void window.removeEventListener("resize",c)),[c]),(0,i.useEffect)(()=>{w(),x()},[t,y,b]),(0,i.useEffect)(()=>w,[]),[e=>{e&&e!==p.current.element&&(w(),p.current.element=e,p.current.scrollContainers=function e(t){let n=[];if(!t||t===document.body)return n;let{overflow:r,overflowX:i,overflowY:o}=window.getComputedStyle(t);return[r,i,o].some(e=>"auto"===e||"scroll"===e)&&n.push(t),[...n,...e(t.parentElement)]}(e),x())},f,g]}({scroll:!0,debounce:{scroll:50,resize:0},...l}),U=i.useRef(null),T=i.useRef(null);i.useImperativeHandle(e,()=>U.current);let D=(0,r.a)(L),[k,I]=i.useState(!1),[R,N]=i.useState(!1);if(k)throw k;if(R)throw R;let H=i.useRef(null);(0,r.b)(()=>{let e=U.current;z.width>0&&z.height>0&&e&&(H.current||(H.current=(0,r.c)(e)),async function(){await H.current.configure({gl:d,scene:O,events:p,shadows:v,linear:g,flat:b,legacy:y,orthographic:w,frameloop:x,dpr:E,performance:S,raycaster:P,camera:A,size:z,onPointerMissed:(...e)=>null==D.current?void 0:D.current(...e),onCreated:e=>{null==e.events.connect||e.events.connect(h?(0,r.i)(h)?h.current:h:T.current),m&&e.setEvents({compute:(e,t)=>{let n=e[m+"X"],r=e[m+"Y"];t.pointer.set(n/t.size.width*2-1,-(2*(r/t.size.height))+1),t.raycaster.setFromCamera(t.pointer,t.camera)}}),null==M||M(e)}}),H.current.render((0,c.jsx)(j,{children:(0,c.jsx)(r.E,{set:N,children:(0,c.jsx)(i.Suspense,{fallback:(0,c.jsx)(r.B,{set:I}),children:null!=t?t:null})})}))}())}),i.useEffect(()=>{let e=U.current;if(e)return()=>(0,r.d)(e)},[]);let B=h?"none":"auto";return(0,c.jsx)("div",{ref:T,style:{position:"relative",width:"100%",height:"100%",overflow:"hidden",pointerEvents:B,...f},..._,children:(0,c.jsx)("div",{ref:C,style:{width:"100%",height:"100%"},children:(0,c.jsx)("canvas",{ref:U,style:{display:"block"},children:n})})})}function f(e){return(0,c.jsx)(l.Af,{children:(0,c.jsx)(u,{...e})})}n(8745)},7575:(e,t,n)=>{n.d(t,{N:()=>v});var r=n(5672),i=n(9590),o=n(2115),s=n(5269),a=Object.defineProperty;class l{constructor(){((e,t)=>{let n,r;r=void 0,(n="symbol"!=typeof t?t+"":t)in e?a(e,n,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[n]=r})(this,"_listeners")}addEventListener(e,t){void 0===this._listeners&&(this._listeners={});let n=this._listeners;void 0===n[e]&&(n[e]=[]),-1===n[e].indexOf(t)&&n[e].push(t)}hasEventListener(e,t){if(void 0===this._listeners)return!1;let n=this._listeners;return void 0!==n[e]&&-1!==n[e].indexOf(t)}removeEventListener(e,t){if(void 0===this._listeners)return;let n=this._listeners[e];if(void 0!==n){let e=n.indexOf(t);-1!==e&&n.splice(e,1)}}dispatchEvent(e){if(void 0===this._listeners)return;let t=this._listeners[e.type];if(void 0!==t){e.target=this;let n=t.slice(0);for(let t=0,r=n.length;t<r;t++)n[t].call(this,e);e.target=null}}}var c=Object.defineProperty,u=(e,t,n)=>{let r;return(r="symbol"!=typeof t?t+"":t)in e?c(e,r,{enumerable:!0,configurable:!0,writable:!0,value:n}):e[r]=n,n};let f=new s.RlV,d=new s.Zcv,p=Math.cos(Math.PI/180*70),h=(e,t)=>(e%t+t)%t;class m extends l{constructor(e,t){super(),u(this,"object"),u(this,"domElement"),u(this,"enabled",!0),u(this,"target",new s.Pq0),u(this,"minDistance",0),u(this,"maxDistance",1/0),u(this,"minZoom",0),u(this,"maxZoom",1/0),u(this,"minPolarAngle",0),u(this,"maxPolarAngle",Math.PI),u(this,"minAzimuthAngle",-1/0),u(this,"maxAzimuthAngle",1/0),u(this,"enableDamping",!1),u(this,"dampingFactor",.05),u(this,"enableZoom",!0),u(this,"zoomSpeed",1),u(this,"enableRotate",!0),u(this,"rotateSpeed",1),u(this,"enablePan",!0),u(this,"panSpeed",1),u(this,"screenSpacePanning",!0),u(this,"keyPanSpeed",7),u(this,"zoomToCursor",!1),u(this,"autoRotate",!1),u(this,"autoRotateSpeed",2),u(this,"reverseOrbit",!1),u(this,"reverseHorizontalOrbit",!1),u(this,"reverseVerticalOrbit",!1),u(this,"keys",{LEFT:"ArrowLeft",UP:"ArrowUp",RIGHT:"ArrowRight",BOTTOM:"ArrowDown"}),u(this,"mouseButtons",{LEFT:s.kBv.ROTATE,MIDDLE:s.kBv.DOLLY,RIGHT:s.kBv.PAN}),u(this,"touches",{ONE:s.wtR.ROTATE,TWO:s.wtR.DOLLY_PAN}),u(this,"target0"),u(this,"position0"),u(this,"zoom0"),u(this,"_domElementKeyEvents",null),u(this,"getPolarAngle"),u(this,"getAzimuthalAngle"),u(this,"setPolarAngle"),u(this,"setAzimuthalAngle"),u(this,"getDistance"),u(this,"getZoomScale"),u(this,"listenToKeyEvents"),u(this,"stopListenToKeyEvents"),u(this,"saveState"),u(this,"reset"),u(this,"update"),u(this,"connect"),u(this,"dispose"),u(this,"dollyIn"),u(this,"dollyOut"),u(this,"getScale"),u(this,"setScale"),this.object=e,this.domElement=t,this.target0=this.target.clone(),this.position0=this.object.position.clone(),this.zoom0=this.object.zoom,this.getPolarAngle=()=>m.phi,this.getAzimuthalAngle=()=>m.theta,this.setPolarAngle=e=>{let t=h(e,2*Math.PI),r=m.phi;r<0&&(r+=2*Math.PI),t<0&&(t+=2*Math.PI);let i=Math.abs(t-r);2*Math.PI-i<i&&(t<r?t+=2*Math.PI:r+=2*Math.PI),v.phi=t-r,n.update()},this.setAzimuthalAngle=e=>{let t=h(e,2*Math.PI),r=m.theta;r<0&&(r+=2*Math.PI),t<0&&(t+=2*Math.PI);let i=Math.abs(t-r);2*Math.PI-i<i&&(t<r?t+=2*Math.PI:r+=2*Math.PI),v.theta=t-r,n.update()},this.getDistance=()=>n.object.position.distanceTo(n.target),this.listenToKeyEvents=e=>{e.addEventListener("keydown",ee),this._domElementKeyEvents=e},this.stopListenToKeyEvents=()=>{this._domElementKeyEvents.removeEventListener("keydown",ee),this._domElementKeyEvents=null},this.saveState=()=>{n.target0.copy(n.target),n.position0.copy(n.object.position),n.zoom0=n.object.zoom},this.reset=()=>{n.target.copy(n.target0),n.object.position.copy(n.position0),n.object.zoom=n.zoom0,n.object.updateProjectionMatrix(),n.dispatchEvent(r),n.update(),l=a.NONE},this.update=(()=>{let t=new s.Pq0,i=new s.Pq0(0,1,0),o=new s.PTz().setFromUnitVectors(e.up,i),u=o.clone().invert(),h=new s.Pq0,y=new s.PTz,w=2*Math.PI;return function(){let x=n.object.position;o.setFromUnitVectors(e.up,i),u.copy(o).invert(),t.copy(x).sub(n.target),t.applyQuaternion(o),m.setFromVector3(t),n.autoRotate&&l===a.NONE&&T(2*Math.PI/60/60*n.autoRotateSpeed),n.enableDamping?(m.theta+=v.theta*n.dampingFactor,m.phi+=v.phi*n.dampingFactor):(m.theta+=v.theta,m.phi+=v.phi);let E=n.minAzimuthAngle,S=n.maxAzimuthAngle;isFinite(E)&&isFinite(S)&&(E<-Math.PI?E+=w:E>Math.PI&&(E-=w),S<-Math.PI?S+=w:S>Math.PI&&(S-=w),E<=S?m.theta=Math.max(E,Math.min(S,m.theta)):m.theta=m.theta>(E+S)/2?Math.max(E,m.theta):Math.min(S,m.theta)),m.phi=Math.max(n.minPolarAngle,Math.min(n.maxPolarAngle,m.phi)),m.makeSafe(),!0===n.enableDamping?n.target.addScaledVector(b,n.dampingFactor):n.target.add(b),n.zoomToCursor&&j||n.object.isOrthographicCamera?m.radius=B(m.radius):m.radius=B(m.radius*g),t.setFromSpherical(m),t.applyQuaternion(u),x.copy(n.target).add(t),n.object.matrixAutoUpdate||n.object.updateMatrix(),n.object.lookAt(n.target),!0===n.enableDamping?(v.theta*=1-n.dampingFactor,v.phi*=1-n.dampingFactor,b.multiplyScalar(1-n.dampingFactor)):(v.set(0,0,0),b.set(0,0,0));let P=!1;if(n.zoomToCursor&&j){let r=null;if(n.object instanceof s.ubm&&n.object.isPerspectiveCamera){let e=t.length();r=B(e*g);let i=e-r;n.object.position.addScaledVector(M,i),n.object.updateMatrixWorld()}else if(n.object.isOrthographicCamera){let e=new s.Pq0(_.x,_.y,0);e.unproject(n.object),n.object.zoom=Math.max(n.minZoom,Math.min(n.maxZoom,n.object.zoom/g)),n.object.updateProjectionMatrix(),P=!0;let i=new s.Pq0(_.x,_.y,0);i.unproject(n.object),n.object.position.sub(i).add(e),n.object.updateMatrixWorld(),r=t.length()}else console.warn("WARNING: OrbitControls.js encountered an unknown camera type - zoom to cursor disabled."),n.zoomToCursor=!1;null!==r&&(n.screenSpacePanning?n.target.set(0,0,-1).transformDirection(n.object.matrix).multiplyScalar(r).add(n.object.position):(f.origin.copy(n.object.position),f.direction.set(0,0,-1).transformDirection(n.object.matrix),Math.abs(n.object.up.dot(f.direction))<p?e.lookAt(n.target):(d.setFromNormalAndCoplanarPoint(n.object.up,n.target),f.intersectPlane(d,n.target))))}else n.object instanceof s.qUd&&n.object.isOrthographicCamera&&(P=1!==g)&&(n.object.zoom=Math.max(n.minZoom,Math.min(n.maxZoom,n.object.zoom/g)),n.object.updateProjectionMatrix());return g=1,j=!1,!!(P||h.distanceToSquared(n.object.position)>c||8*(1-y.dot(n.object.quaternion))>c)&&(n.dispatchEvent(r),h.copy(n.object.position),y.copy(n.object.quaternion),P=!1,!0)}})(),this.connect=e=>{n.domElement=e,n.domElement.style.touchAction="none",n.domElement.addEventListener("contextmenu",et),n.domElement.addEventListener("pointerdown",K),n.domElement.addEventListener("pointercancel",$),n.domElement.addEventListener("wheel",J)},this.dispose=()=>{var e,t,r,i,o,s;n.domElement&&(n.domElement.style.touchAction="auto"),null==(e=n.domElement)||e.removeEventListener("contextmenu",et),null==(t=n.domElement)||t.removeEventListener("pointerdown",K),null==(r=n.domElement)||r.removeEventListener("pointercancel",$),null==(i=n.domElement)||i.removeEventListener("wheel",J),null==(o=n.domElement)||o.ownerDocument.removeEventListener("pointermove",Q),null==(s=n.domElement)||s.ownerDocument.removeEventListener("pointerup",$),null!==n._domElementKeyEvents&&n._domElementKeyEvents.removeEventListener("keydown",ee)};const n=this,r={type:"change"},i={type:"start"},o={type:"end"},a={NONE:-1,ROTATE:0,DOLLY:1,PAN:2,TOUCH_ROTATE:3,TOUCH_PAN:4,TOUCH_DOLLY_PAN:5,TOUCH_DOLLY_ROTATE:6};let l=a.NONE;const c=1e-6,m=new s.YHV,v=new s.YHV;let g=1;const b=new s.Pq0,y=new s.I9Y,w=new s.I9Y,x=new s.I9Y,E=new s.I9Y,S=new s.I9Y,P=new s.I9Y,A=new s.I9Y,O=new s.I9Y,L=new s.I9Y,M=new s.Pq0,_=new s.I9Y;let j=!1;const C=[],z={};function U(){return Math.pow(.95,n.zoomSpeed)}function T(e){n.reverseOrbit||n.reverseHorizontalOrbit?v.theta+=e:v.theta-=e}function D(e){n.reverseOrbit||n.reverseVerticalOrbit?v.phi+=e:v.phi-=e}const k=(()=>{let e=new s.Pq0;return function(t,n){e.setFromMatrixColumn(n,0),e.multiplyScalar(-t),b.add(e)}})(),I=(()=>{let e=new s.Pq0;return function(t,r){!0===n.screenSpacePanning?e.setFromMatrixColumn(r,1):(e.setFromMatrixColumn(r,0),e.crossVectors(n.object.up,e)),e.multiplyScalar(t),b.add(e)}})(),R=(()=>{let e=new s.Pq0;return function(t,r){let i=n.domElement;if(i&&n.object instanceof s.ubm&&n.object.isPerspectiveCamera){let o=n.object.position;e.copy(o).sub(n.target);let s=e.length();k(2*t*(s*=Math.tan(n.object.fov/2*Math.PI/180))/i.clientHeight,n.object.matrix),I(2*r*s/i.clientHeight,n.object.matrix)}else i&&n.object instanceof s.qUd&&n.object.isOrthographicCamera?(k(t*(n.object.right-n.object.left)/n.object.zoom/i.clientWidth,n.object.matrix),I(r*(n.object.top-n.object.bottom)/n.object.zoom/i.clientHeight,n.object.matrix)):(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - pan disabled."),n.enablePan=!1)}})();function N(e){n.object instanceof s.ubm&&n.object.isPerspectiveCamera||n.object instanceof s.qUd&&n.object.isOrthographicCamera?g=e:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),n.enableZoom=!1)}function H(e){if(!n.zoomToCursor||!n.domElement)return;j=!0;let t=n.domElement.getBoundingClientRect(),r=e.clientX-t.left,i=e.clientY-t.top,o=t.width,s=t.height;_.x=r/o*2-1,_.y=-(i/s*2)+1,M.set(_.x,_.y,1).unproject(n.object).sub(n.object.position).normalize()}function B(e){return Math.max(n.minDistance,Math.min(n.maxDistance,e))}function F(e){y.set(e.clientX,e.clientY)}function q(e){E.set(e.clientX,e.clientY)}function V(){if(1==C.length)y.set(C[0].pageX,C[0].pageY);else{let e=.5*(C[0].pageX+C[1].pageX),t=.5*(C[0].pageY+C[1].pageY);y.set(e,t)}}function Y(){if(1==C.length)E.set(C[0].pageX,C[0].pageY);else{let e=.5*(C[0].pageX+C[1].pageX),t=.5*(C[0].pageY+C[1].pageY);E.set(e,t)}}function W(){let e=C[0].pageX-C[1].pageX,t=C[0].pageY-C[1].pageY,n=Math.sqrt(e*e+t*t);A.set(0,n)}function G(e){if(1==C.length)w.set(e.pageX,e.pageY);else{let t=er(e),n=.5*(e.pageX+t.x),r=.5*(e.pageY+t.y);w.set(n,r)}x.subVectors(w,y).multiplyScalar(n.rotateSpeed);let t=n.domElement;t&&(T(2*Math.PI*x.x/t.clientHeight),D(2*Math.PI*x.y/t.clientHeight)),y.copy(w)}function X(e){if(1==C.length)S.set(e.pageX,e.pageY);else{let t=er(e),n=.5*(e.pageX+t.x),r=.5*(e.pageY+t.y);S.set(n,r)}P.subVectors(S,E).multiplyScalar(n.panSpeed),R(P.x,P.y),E.copy(S)}function Z(e){var t;let r=er(e),i=e.pageX-r.x,o=e.pageY-r.y,s=Math.sqrt(i*i+o*o);O.set(0,s),L.set(0,Math.pow(O.y/A.y,n.zoomSpeed)),t=L.y,N(g/t),A.copy(O)}function K(e){var t,r,o;!1!==n.enabled&&(0===C.length&&(null==(t=n.domElement)||t.ownerDocument.addEventListener("pointermove",Q),null==(r=n.domElement)||r.ownerDocument.addEventListener("pointerup",$)),o=e,C.push(o),"touch"===e.pointerType?function(e){switch(en(e),C.length){case 1:switch(n.touches.ONE){case s.wtR.ROTATE:if(!1===n.enableRotate)return;V(),l=a.TOUCH_ROTATE;break;case s.wtR.PAN:if(!1===n.enablePan)return;Y(),l=a.TOUCH_PAN;break;default:l=a.NONE}break;case 2:switch(n.touches.TWO){case s.wtR.DOLLY_PAN:if(!1===n.enableZoom&&!1===n.enablePan)return;n.enableZoom&&W(),n.enablePan&&Y(),l=a.TOUCH_DOLLY_PAN;break;case s.wtR.DOLLY_ROTATE:if(!1===n.enableZoom&&!1===n.enableRotate)return;n.enableZoom&&W(),n.enableRotate&&V(),l=a.TOUCH_DOLLY_ROTATE;break;default:l=a.NONE}break;default:l=a.NONE}l!==a.NONE&&n.dispatchEvent(i)}(e):function(e){let t;switch(e.button){case 0:t=n.mouseButtons.LEFT;break;case 1:t=n.mouseButtons.MIDDLE;break;case 2:t=n.mouseButtons.RIGHT;break;default:t=-1}switch(t){case s.kBv.DOLLY:if(!1===n.enableZoom)return;H(e),A.set(e.clientX,e.clientY),l=a.DOLLY;break;case s.kBv.ROTATE:if(e.ctrlKey||e.metaKey||e.shiftKey){if(!1===n.enablePan)return;q(e),l=a.PAN}else{if(!1===n.enableRotate)return;F(e),l=a.ROTATE}break;case s.kBv.PAN:if(e.ctrlKey||e.metaKey||e.shiftKey){if(!1===n.enableRotate)return;F(e),l=a.ROTATE}else{if(!1===n.enablePan)return;q(e),l=a.PAN}break;default:l=a.NONE}l!==a.NONE&&n.dispatchEvent(i)}(e))}function Q(e){!1!==n.enabled&&("touch"===e.pointerType?function(e){switch(en(e),l){case a.TOUCH_ROTATE:if(!1===n.enableRotate)return;G(e),n.update();break;case a.TOUCH_PAN:if(!1===n.enablePan)return;X(e),n.update();break;case a.TOUCH_DOLLY_PAN:if(!1===n.enableZoom&&!1===n.enablePan)return;n.enableZoom&&Z(e),n.enablePan&&X(e),n.update();break;case a.TOUCH_DOLLY_ROTATE:if(!1===n.enableZoom&&!1===n.enableRotate)return;n.enableZoom&&Z(e),n.enableRotate&&G(e),n.update();break;default:l=a.NONE}}(e):function(e){if(!1!==n.enabled)switch(l){case a.ROTATE:let t;if(!1===n.enableRotate)return;w.set(e.clientX,e.clientY),x.subVectors(w,y).multiplyScalar(n.rotateSpeed),(t=n.domElement)&&(T(2*Math.PI*x.x/t.clientHeight),D(2*Math.PI*x.y/t.clientHeight)),y.copy(w),n.update();break;case a.DOLLY:var r,i;if(!1===n.enableZoom)return;(O.set(e.clientX,e.clientY),L.subVectors(O,A),L.y>0)?(r=U(),N(g/r)):L.y<0&&(i=U(),N(g*i)),A.copy(O),n.update();break;case a.PAN:if(!1===n.enablePan)return;S.set(e.clientX,e.clientY),P.subVectors(S,E).multiplyScalar(n.panSpeed),R(P.x,P.y),E.copy(S),n.update()}}(e))}function $(e){var t,r,i;(function(e){delete z[e.pointerId];for(let t=0;t<C.length;t++)if(C[t].pointerId==e.pointerId)return void C.splice(t,1)})(e),0===C.length&&(null==(t=n.domElement)||t.releasePointerCapture(e.pointerId),null==(r=n.domElement)||r.ownerDocument.removeEventListener("pointermove",Q),null==(i=n.domElement)||i.ownerDocument.removeEventListener("pointerup",$)),n.dispatchEvent(o),l=a.NONE}function J(e){if(!1!==n.enabled&&!1!==n.enableZoom&&(l===a.NONE||l===a.ROTATE)){var t,r;e.preventDefault(),n.dispatchEvent(i),(H(e),e.deltaY<0)?(t=U(),N(g*t)):e.deltaY>0&&(r=U(),N(g/r)),n.update(),n.dispatchEvent(o)}}function ee(e){if(!1!==n.enabled&&!1!==n.enablePan){let t=!1;switch(e.code){case n.keys.UP:R(0,n.keyPanSpeed),t=!0;break;case n.keys.BOTTOM:R(0,-n.keyPanSpeed),t=!0;break;case n.keys.LEFT:R(n.keyPanSpeed,0),t=!0;break;case n.keys.RIGHT:R(-n.keyPanSpeed,0),t=!0}t&&(e.preventDefault(),n.update())}}function et(e){!1!==n.enabled&&e.preventDefault()}function en(e){let t=z[e.pointerId];void 0===t&&(t=new s.I9Y,z[e.pointerId]=t),t.set(e.pageX,e.pageY)}function er(e){return z[(e.pointerId===C[0].pointerId?C[1]:C[0]).pointerId]}this.dollyIn=(e=U())=>{N(g*e),n.update()},this.dollyOut=(e=U())=>{N(g/e),n.update()},this.getScale=()=>g,this.setScale=e=>{N(e),n.update()},this.getZoomScale=()=>U(),void 0!==t&&this.connect(t),this.update()}}let v=o.forwardRef(({makeDefault:e,camera:t,regress:n,domElement:s,enableDamping:a=!0,keyEvents:l=!1,onChange:c,onStart:u,onEnd:f,...d},p)=>{let h=(0,i.C)(e=>e.invalidate),v=(0,i.C)(e=>e.camera),g=(0,i.C)(e=>e.gl),b=(0,i.C)(e=>e.events),y=(0,i.C)(e=>e.setEvents),w=(0,i.C)(e=>e.set),x=(0,i.C)(e=>e.get),E=(0,i.C)(e=>e.performance),S=t||v,P=s||b.connected||g.domElement,A=o.useMemo(()=>new m(S),[S]);return(0,i.D)(()=>{A.enabled&&A.update()},-1),o.useEffect(()=>(l&&A.connect(!0===l?P:l),A.connect(P),()=>void A.dispose()),[l,P,n,A,h]),o.useEffect(()=>{let e=e=>{h(),n&&E.regress(),c&&c(e)},t=e=>{u&&u(e)},r=e=>{f&&f(e)};return A.addEventListener("change",e),A.addEventListener("start",t),A.addEventListener("end",r),()=>{A.removeEventListener("start",t),A.removeEventListener("end",r),A.removeEventListener("change",e)}},[c,u,f,A,h,y]),o.useEffect(()=>{if(e){let e=x().controls;return w({controls:A}),()=>w({controls:e})}},[e,A]),o.createElement("primitive",(0,r.A)({ref:p,object:A,enableDamping:a},d))})},7924:(e,t,n)=>{n.d(t,{V:()=>i});var r=n(5269);class i extends r.aHM{constructor(e){super(e)}load(e,t,n,i){let o=this,s=""===this.path?r.r6x.extractUrlBase(e):this.path,a=new r.Y9S(this.manager);a.setPath(this.path),a.setRequestHeader(this.requestHeader),a.setWithCredentials(this.withCredentials),a.load(e,function(n){try{t(o.parse(n,s))}catch(t){i?i(t):console.error(t),o.manager.itemError(e)}},n,i)}setMaterialOptions(e){return this.materialOptions=e,this}parse(e,t){let n=e.split("\n"),r={},i=/\s+/,s={};for(let e=0;e<n.length;e++){let t=n[e];if(0===(t=t.trim()).length||"#"===t.charAt(0))continue;let o=t.indexOf(" "),a=o>=0?t.substring(0,o):t;a=a.toLowerCase();let l=o>=0?t.substring(o+1):"";if(l=l.trim(),"newmtl"===a)r={name:l},s[l]=r;else if("ka"===a||"kd"===a||"ks"===a||"ke"===a){let e=l.split(i,3);r[a]=[parseFloat(e[0]),parseFloat(e[1]),parseFloat(e[2])]}else r[a]=l}let a=new o(this.resourcePath||t,this.materialOptions);return a.setCrossOrigin(this.crossOrigin),a.setManager(this.manager),a.setMaterials(s),a}}class o{constructor(e="",t={}){this.baseUrl=e,this.options=t,this.materialsInfo={},this.materials={},this.materialsArray=[],this.nameLookup={},this.crossOrigin="anonymous",this.side=void 0!==this.options.side?this.options.side:r.hB5,this.wrap=void 0!==this.options.wrap?this.options.wrap:r.GJx}setCrossOrigin(e){return this.crossOrigin=e,this}setManager(e){this.manager=e}setMaterials(e){this.materialsInfo=this.convert(e),this.materials={},this.materialsArray=[],this.nameLookup={}}convert(e){if(!this.options)return e;let t={};for(let n in e){let r=e[n],i={};for(let e in t[n]=i,r){let t=!0,n=r[e],o=e.toLowerCase();switch(o){case"kd":case"ka":case"ks":this.options&&this.options.normalizeRGB&&(n=[n[0]/255,n[1]/255,n[2]/255]),this.options&&this.options.ignoreZeroRGBs&&0===n[0]&&0===n[1]&&0===n[2]&&(t=!1)}t&&(i[o]=n)}}return t}preload(){for(let e in this.materialsInfo)this.create(e)}getIndex(e){return this.nameLookup[e]}getAsArray(){let e=0;for(let t in this.materialsInfo)this.materialsArray[e]=this.create(t),this.nameLookup[t]=e,e++;return this.materialsArray}create(e){return void 0===this.materials[e]&&this.createMaterial_(e),this.materials[e]}createMaterial_(e){let t=this,n=this.materialsInfo[e],i={name:e,side:this.side};function o(e,n){var o,s;if(i[e])return;let a=t.getTextureParams(n,i),l=t.loadTexture((o=t.baseUrl,"string"!=typeof(s=a.url)||""===s?"":/^https?:\/\//i.test(s)?s:o+s));l.repeat.copy(a.scale),l.offset.copy(a.offset),l.wrapS=t.wrap,l.wrapT=t.wrap,("map"===e||"emissiveMap"===e)&&(l.colorSpace=r.er$),i[e]=l}for(let e in n){let t,s=n[e];if(""!==s)switch(e.toLowerCase()){case"kd":i.color=r.ppV.colorSpaceToWorking(new r.Q1f().fromArray(s),r.er$);break;case"ks":i.specular=r.ppV.colorSpaceToWorking(new r.Q1f().fromArray(s),r.er$);break;case"ke":i.emissive=r.ppV.colorSpaceToWorking(new r.Q1f().fromArray(s),r.er$);break;case"map_kd":o("map",s);break;case"map_ks":o("specularMap",s);break;case"map_ke":o("emissiveMap",s);break;case"norm":o("normalMap",s);break;case"map_bump":case"bump":o("bumpMap",s);break;case"disp":o("displacementMap",s);break;case"map_d":o("alphaMap",s),i.transparent=!0;break;case"ns":i.shininess=parseFloat(s);break;case"d":(t=parseFloat(s))<1&&(i.opacity=t,i.transparent=!0);break;case"tr":t=parseFloat(s),this.options&&this.options.invertTrProperty&&(t=1-t),t>0&&(i.opacity=1-t,i.transparent=!0)}}return this.materials[e]=new r.tXL(i),this.materials[e]}getTextureParams(e,t){let n,i={scale:new r.I9Y(1,1),offset:new r.I9Y(0,0)},o=e.split(/\s+/);return(n=o.indexOf("-bm"))>=0&&(t.bumpScale=parseFloat(o[n+1]),o.splice(n,2)),(n=o.indexOf("-mm"))>=0&&(t.displacementBias=parseFloat(o[n+1]),t.displacementScale=parseFloat(o[n+2]),o.splice(n,3)),(n=o.indexOf("-s"))>=0&&(i.scale.set(parseFloat(o[n+1]),parseFloat(o[n+2])),o.splice(n,4)),(n=o.indexOf("-o"))>=0&&(i.offset.set(parseFloat(o[n+1]),parseFloat(o[n+2])),o.splice(n,4)),i.url=o.join(" ").trim(),i}loadTexture(e,t,n,i,o){let s=void 0!==this.manager?this.manager:r.h_9,a=s.getHandler(e);null===a&&(a=new r.Tap(s)),a.setCrossOrigin&&a.setCrossOrigin(this.crossOrigin);let l=a.load(e,n,i,o);return void 0!==t&&(l.mapping=t),l}}},7930:(e,t)=>{function n(e,t){var n=e.length;for(e.push(t);0<n;){var r=n-1>>>1,i=e[r];if(0<o(i,t))e[r]=t,e[n]=i,n=r;else break}}function r(e){return 0===e.length?null:e[0]}function i(e){if(0===e.length)return null;var t=e[0],n=e.pop();if(n!==t){e[0]=n;for(var r=0,i=e.length,s=i>>>1;r<s;){var a=2*(r+1)-1,l=e[a],c=a+1,u=e[c];if(0>o(l,n))c<i&&0>o(u,l)?(e[r]=u,e[c]=n,r=c):(e[r]=l,e[a]=n,r=a);else if(c<i&&0>o(u,n))e[r]=u,e[c]=n,r=c;else break}}return t}function o(e,t){var n=e.sortIndex-t.sortIndex;return 0!==n?n:e.id-t.id}if(t.unstable_now=void 0,"object"==typeof performance&&"function"==typeof performance.now){var s,a=performance;t.unstable_now=function(){return a.now()}}else{var l=Date,c=l.now();t.unstable_now=function(){return l.now()-c}}var u=[],f=[],d=1,p=null,h=3,m=!1,v=!1,g=!1,b=!1,y="function"==typeof setTimeout?setTimeout:null,w="function"==typeof clearTimeout?clearTimeout:null,x="u">typeof setImmediate?setImmediate:null;function E(e){for(var t=r(f);null!==t;){if(null===t.callback)i(f);else if(t.startTime<=e)i(f),t.sortIndex=t.expirationTime,n(u,t);else break;t=r(f)}}function S(e){if(g=!1,E(e),!v)if(null!==r(u))v=!0,P||(P=!0,s());else{var t=r(f);null!==t&&z(S,t.startTime-e)}}var P=!1,A=-1,O=5,L=-1;function M(){return!!b||!(t.unstable_now()-L<O)}function _(){if(b=!1,P){var e=t.unstable_now();L=e;var n=!0;try{e:{v=!1,g&&(g=!1,w(A),A=-1),m=!0;var o=h;try{t:{for(E(e),p=r(u);null!==p&&!(p.expirationTime>e&&M());){var a=p.callback;if("function"==typeof a){p.callback=null,h=p.priorityLevel;var l=a(p.expirationTime<=e);if(e=t.unstable_now(),"function"==typeof l){p.callback=l,E(e),n=!0;break t}p===r(u)&&i(u),E(e)}else i(u);p=r(u)}if(null!==p)n=!0;else{var c=r(f);null!==c&&z(S,c.startTime-e),n=!1}}break e}finally{p=null,h=o,m=!1}}}finally{n?s():P=!1}}}if("function"==typeof x)s=function(){x(_)};else if("u">typeof MessageChannel){var j=new MessageChannel,C=j.port2;j.port1.onmessage=_,s=function(){C.postMessage(null)}}else s=function(){y(_,0)};function z(e,n){A=y(function(){e(t.unstable_now())},n)}t.unstable_IdlePriority=5,t.unstable_ImmediatePriority=1,t.unstable_LowPriority=4,t.unstable_NormalPriority=3,t.unstable_Profiling=null,t.unstable_UserBlockingPriority=2,t.unstable_cancelCallback=function(e){e.callback=null},t.unstable_forceFrameRate=function(e){0>e||125<e?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):O=0<e?Math.floor(1e3/e):5},t.unstable_getCurrentPriorityLevel=function(){return h},t.unstable_next=function(e){switch(h){case 1:case 2:case 3:var t=3;break;default:t=h}var n=h;h=t;try{return e()}finally{h=n}},t.unstable_requestPaint=function(){b=!0},t.unstable_runWithPriority=function(e,t){switch(e){case 1:case 2:case 3:case 4:case 5:break;default:e=3}var n=h;h=e;try{return t()}finally{h=n}},t.unstable_scheduleCallback=function(e,i,o){var a=t.unstable_now();switch(o="object"==typeof o&&null!==o&&"number"==typeof(o=o.delay)&&0<o?a+o:a,e){case 1:var l=-1;break;case 2:l=250;break;case 5:l=0x3fffffff;break;case 4:l=1e4;break;default:l=5e3}return l=o+l,e={id:d++,callback:i,priorityLevel:e,startTime:o,expirationTime:l,sortIndex:-1},o>a?(e.sortIndex=o,n(f,e),null===r(u)&&e===r(f)&&(g?(w(A),A=-1):g=!0,z(S,o-a))):(e.sortIndex=l,n(u,e),v||m||(v=!0,P||(P=!0,s()))),e},t.unstable_shouldYield=M,t.unstable_wrapCallback=function(e){var t=h;return function(){var n=h;h=t;try{return e.apply(this,arguments)}finally{h=n}}}},8039:(e,t,n)=>{e.exports=n(5538)},8745:(e,t,n)=>{e.exports=n(7930)},9007:(e,t,n)=>{n.d(t,{_:()=>c});var r=n(5672),i=n(2115),o=n(5269),s=n(9590);let a={uniforms:{tDiffuse:{value:null},h:{value:1/512}},vertexShader:`
      varying vec2 vUv;

      void main() {

        vUv = uv;
        gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

      }
  `,fragmentShader:`
    uniform sampler2D tDiffuse;
    uniform float h;

    varying vec2 vUv;

    void main() {

    	vec4 sum = vec4( 0.0 );

    	sum += texture2D( tDiffuse, vec2( vUv.x - 4.0 * h, vUv.y ) ) * 0.051;
    	sum += texture2D( tDiffuse, vec2( vUv.x - 3.0 * h, vUv.y ) ) * 0.0918;
    	sum += texture2D( tDiffuse, vec2( vUv.x - 2.0 * h, vUv.y ) ) * 0.12245;
    	sum += texture2D( tDiffuse, vec2( vUv.x - 1.0 * h, vUv.y ) ) * 0.1531;
    	sum += texture2D( tDiffuse, vec2( vUv.x, vUv.y ) ) * 0.1633;
    	sum += texture2D( tDiffuse, vec2( vUv.x + 1.0 * h, vUv.y ) ) * 0.1531;
    	sum += texture2D( tDiffuse, vec2( vUv.x + 2.0 * h, vUv.y ) ) * 0.12245;
    	sum += texture2D( tDiffuse, vec2( vUv.x + 3.0 * h, vUv.y ) ) * 0.0918;
    	sum += texture2D( tDiffuse, vec2( vUv.x + 4.0 * h, vUv.y ) ) * 0.051;

    	gl_FragColor = sum;

    }
  `},l={uniforms:{tDiffuse:{value:null},v:{value:1/512}},vertexShader:`
    varying vec2 vUv;

    void main() {

      vUv = uv;
      gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

    }
  `,fragmentShader:`

  uniform sampler2D tDiffuse;
  uniform float v;

  varying vec2 vUv;

  void main() {

    vec4 sum = vec4( 0.0 );

    sum += texture2D( tDiffuse, vec2( vUv.x, vUv.y - 4.0 * v ) ) * 0.051;
    sum += texture2D( tDiffuse, vec2( vUv.x, vUv.y - 3.0 * v ) ) * 0.0918;
    sum += texture2D( tDiffuse, vec2( vUv.x, vUv.y - 2.0 * v ) ) * 0.12245;
    sum += texture2D( tDiffuse, vec2( vUv.x, vUv.y - 1.0 * v ) ) * 0.1531;
    sum += texture2D( tDiffuse, vec2( vUv.x, vUv.y ) ) * 0.1633;
    sum += texture2D( tDiffuse, vec2( vUv.x, vUv.y + 1.0 * v ) ) * 0.1531;
    sum += texture2D( tDiffuse, vec2( vUv.x, vUv.y + 2.0 * v ) ) * 0.12245;
    sum += texture2D( tDiffuse, vec2( vUv.x, vUv.y + 3.0 * v ) ) * 0.0918;
    sum += texture2D( tDiffuse, vec2( vUv.x, vUv.y + 4.0 * v ) ) * 0.051;

    gl_FragColor = sum;

  }
  `},c=i.forwardRef(({scale:e=10,frames:t=1/0,opacity:n=1,width:c=1,height:u=1,blur:f=1,near:d=0,far:p=10,resolution:h=512,smooth:m=!0,color:v="#000000",depthWrite:g=!1,renderOrder:b,...y},w)=>{let x,E,S=i.useRef(null),P=(0,s.C)(e=>e.scene),A=(0,s.C)(e=>e.gl),O=i.useRef(null);c*=Array.isArray(e)?e[0]:e||1,u*=Array.isArray(e)?e[1]:e||1;let[L,M,_,j,C,z,U]=i.useMemo(()=>{let e=new o.nWS(h,h),t=new o.nWS(h,h);t.texture.generateMipmaps=e.texture.generateMipmaps=!1;let n=new o.bdM(c,u).rotateX(Math.PI/2),r=new o.eaF(n),i=new o.CSG;i.depthTest=i.depthWrite=!1,i.onBeforeCompile=e=>{e.uniforms={...e.uniforms,ucolor:{value:new o.Q1f(v)}},e.fragmentShader=e.fragmentShader.replace("void main() {",`uniform vec3 ucolor;
           void main() {
          `),e.fragmentShader=e.fragmentShader.replace("vec4( vec3( 1.0 - fragCoordZ ), opacity );","vec4( ucolor * fragCoordZ * 2.0, ( 1.0 - fragCoordZ ) * 1.0 );")};let s=new o.BKk(a),f=new o.BKk(l);return f.depthTest=s.depthTest=!1,[e,n,i,r,s,f,t]},[h,c,u,e,v]),T=e=>{j.visible=!0,j.material=C,C.uniforms.tDiffuse.value=L.texture,C.uniforms.h.value=e/256,A.setRenderTarget(U),A.render(j,O.current),j.material=z,z.uniforms.tDiffuse.value=U.texture,z.uniforms.v.value=e/256,A.setRenderTarget(L),A.render(j,O.current),j.visible=!1},D=0;return(0,s.D)(()=>{O.current&&(t===1/0||D<t)&&(D++,x=P.background,E=P.overrideMaterial,S.current.visible=!1,P.background=null,P.overrideMaterial=_,A.setRenderTarget(L),A.render(P,O.current),T(f),m&&T(.4*f),A.setRenderTarget(null),S.current.visible=!0,P.overrideMaterial=E,P.background=x)}),i.useImperativeHandle(w,()=>S.current,[]),i.createElement("group",(0,r.A)({"rotation-x":Math.PI/2},y,{ref:S}),i.createElement("mesh",{renderOrder:b,geometry:M,scale:[1,-1,1],rotation:[-Math.PI/2,0,0]},i.createElement("meshBasicMaterial",{transparent:!0,map:L.texture,opacity:n,depthWrite:g})),i.createElement("orthographicCamera",{ref:O,args:[-c/2,c/2,u/2,-u/2,d,p]}))})},9326:(e,t,n)=>{n.d(t,{DY:()=>s,IU:()=>l,uv:()=>a});let r=[];function i(e,t,n=(e,t)=>e===t){if(e===t)return!0;if(!e||!t)return!1;let r=e.length;if(t.length!==r)return!1;for(let i=0;i<r;i++)if(!n(e[i],t[i]))return!1;return!0}function o(e,t=null,n=!1,s={}){for(let o of(null===t&&(t=[e]),r))if(i(t,o.keys,o.equal)){if(n)return;if(Object.prototype.hasOwnProperty.call(o,"error"))throw o.error;if(Object.prototype.hasOwnProperty.call(o,"response"))return s.lifespan&&s.lifespan>0&&(o.timeout&&clearTimeout(o.timeout),o.timeout=setTimeout(o.remove,s.lifespan)),o.response;if(!n)throw o.promise}let a={keys:t,equal:s.equal,remove:()=>{let e=r.indexOf(a);-1!==e&&r.splice(e,1)},promise:("object"==typeof e&&"function"==typeof e.then?e:e(...t)).then(e=>{a.response=e,s.lifespan&&s.lifespan>0&&(a.timeout=setTimeout(a.remove,s.lifespan))}).catch(e=>a.error=e)};if(r.push(a),!n)throw a.promise}let s=(e,t,n)=>o(e,t,!1,n),a=(e,t,n)=>void o(e,t,!0,n),l=e=>{if(void 0===e||0===e.length)r.splice(0,r.length);else{let t=r.find(t=>i(e,t.keys,t.equal));t&&t.remove()}}},9339:(e,t,n)=>{e.exports=n(9617)},9617:(e,t,n)=>{var r=n(2115),i=n(8039),o="function"==typeof Object.is?Object.is:function(e,t){return e===t&&(0!==e||1/e==1/t)||e!=e&&t!=t},s=i.useSyncExternalStore,a=r.useRef,l=r.useEffect,c=r.useMemo,u=r.useDebugValue;t.useSyncExternalStoreWithSelector=function(e,t,n,r,i){var f=a(null);if(null===f.current){var d={hasValue:!1,value:null};f.current=d}else d=f.current;var p=s(e,(f=c(function(){function e(e){if(!l){if(l=!0,s=e,e=r(e),void 0!==i&&d.hasValue){var t=d.value;if(i(t,e))return a=t}return a=e}if(t=a,o(s,e))return t;var n=r(e);return void 0!==i&&i(t,n)?(s=e,t):(s=e,a=n)}var s,a,l=!1,c=void 0===n?null:n;return[function(){return e(t())},null===c?void 0:function(){return e(c())}]},[t,n,r,i]))[0],f[1]);return l(function(){d.hasValue=!0,d.value=p},[p]),u(p),p}}}]);