"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[615],{4615:(e,t,r)=>{r.r(t),r.d(t,{EspScene:()=>H});var a=r(5155),o=r(2115),n=r(9590),i=r(6275),s=r(4184),l=r(7575),c=r(9007),u=r(5269),m=r(5282),f=r(7924),d=r(8593),p=r(3121),h=r(5331),x=r(5359);function y(e){return!!(e.userData?.chamOverlay||e.userData?.espBranding)}function v(e){return/^Handle/i.test(e)}function g(e){let t=e.geometry.attributes.position;if(!t)return new u.NRn;let r=new u.NRn().setFromBufferAttribute(t);return r.applyMatrix4(e.matrix),r}let w={head:new u.Q1f("#f1d04d"),arms:new u.Q1f("#f1d04d"),torso:new u.Q1f("#1c6ca7"),legs:new u.Q1f("#93a944")},M=null,b=!1,j=new Set;function F(e){if("u"<typeof document)return null;if(M)return e?.(M),M;if(e&&j.add(e),b)return null;b=!0;let t=new Image;return t.crossOrigin="anonymous",t.onload=()=>{for(let e of(M=function(e){let t=document.createElement("canvas");t.width=1024,t.height=1024;let r=t.getContext("2d");if(!r)return new u.GOR(t);r.clearRect(0,0,1024,1024);let a=Math.min(901.12/e.width,901.12/e.height),o=e.width*a,n=e.height*a;r.drawImage(e,(1024-o)/2,(1024-n)/2,o,n);let i=r.getImageData(0,0,1024,1024),s=i.data;for(let e=0;e<s.length;e+=4){let t=s[e],r=s[e+1],a=s[e+2];t<24&&r<24&&a<24&&(s[e+3]=0)}r.putImageData(i,0,0);let l=new u.GOR(t);return l.colorSpace=u.er$,l.anisotropy=8,l.minFilter=u.k6q,l.magFilter=u.k6q,l.generateMipmaps=!1,l.needsUpdate=!0,l}(t),j))e(M);j.clear()},t.onerror=()=>{b=!1,j.clear()},t.src="/gain-logo.png",null}function z(e,t){let r=function(e){let t,r=function(e){if(0===e.length)return{torso:null,lArm:null,rArm:null,lLeg:null,rLeg:null};let t=new u.NRn;e.forEach(e=>t.union(new u.NRn(e.min,e.max)));let r=t.min.x,a=t.max.x,o=t.min.y,n=t.max.y,i=(r+a)*.5,s=Math.max(.01,n-o),l=Math.max(.01,a-r),c=e.map(e=>({aabb:e,cx:(e.min.x+e.max.x)*.5,sy:e.max.y-e.min.y,sx:e.max.x-e.min.x,foot:e.min.y})),m=null,f=-1;for(let e of c){if(Math.abs(e.cx-i)>.42*l)continue;let t=3*e.sy+e.sx;t>f&&(f=t,m=e.aabb)}m||(m=c.reduce((e,t)=>t.sy>e.sy?t:e).aabb);let d=c.filter(e=>e.aabb!==m).sort((e,t)=>e.foot-t.foot),p=d[0]?.aabb??null,h=d[1]?.aabb??null;p&&h&&(p.min.x+p.max.x)*.5>(h.min.x+h.max.x)*.5&&([p,h]=[h,p]);let x=c.filter(e=>!(e.aabb===m||e.aabb===p||e.aabb===h||Math.abs(e.cx-i)<.2*l)&&e.foot>o+.2*s),y=x.find(e=>e.cx<i)?.aabb??null,v=x.find(e=>e.cx>=i)?.aabb??null;return{torso:m,lArm:y,rArm:v,lLeg:p,rLeg:h}}((e.updateMatrixWorld(!0),t=[],e.traverse(r=>{let a,o;if(!(r instanceof u.eaF)||y(r))return;let n=(e.updateMatrixWorld(!0),a=e.matrixWorld.clone().invert(),(o=new u.NRn().setFromObject(r)).applyMatrix4(a),o);n.isEmpty()||t.push({min:n.min.clone(),max:n.max.clone()})}),t));if(!r.torso)return null;let a=new u.Pq0((r.torso.min.x+r.torso.max.x)*.5,(r.torso.min.y+r.torso.max.y)*.5,(r.torso.min.z+r.torso.max.z)*.5);e.updateMatrixWorld(!0);let o=e.matrixWorld.clone().invert(),n=null,i=1/0,s=new u.Pq0,l=new u.NRn;return e.traverse(e=>{if(!(e instanceof u.eaF)||y(e)||!e.geometry||(l.setFromObject(e),l.isEmpty()))return;l.applyMatrix4(o),l.getCenter(s);let t=s.distanceTo(a);t<i&&(i=t,n=e)}),n}(e);if(!r)return()=>{};e.updateMatrixWorld(!0),r.updateMatrixWorld(!0);let a=new u.NRn().setFromObject(r),o=a.getSize(new u.Pq0),n=a.getCenter(new u.Pq0),i=new u.Pq0(n.x,n.y+.015*o.y,a.max.z),s=.34*Math.min(o.x,o.y),l=new x.w(r,i,new u.O9p(0,0,0),new u.Pq0(s,s,Math.max(.08,.28*o.z)));l.applyMatrix4(e.matrixWorld.clone().invert());let c=new u.eaF(l,new u._4j({map:t,color:0xffffff,transparent:!0,alphaTest:.08,depthWrite:!1,roughness:.9,metalness:0,polygonOffset:!0,polygonOffsetFactor:-2,polygonOffsetUnits:-2}));return c.userData.espBranding=!0,c.renderOrder=8,c.castShadow=!1,c.receiveShadow=!1,e.add(c),()=>{c.removeFromParent(),c.geometry.dispose(),c.material instanceof u.imn&&c.material.dispose()}}function P(){let[e,t]=(0,o.useState)(()=>F());return((0,o.useEffect)(()=>{F(t)},[]),e)?(0,a.jsx)(h.C,{position:[0,.06,.5],rotation:[0,0,0],scale:.78,children:(0,a.jsx)("meshStandardMaterial",{map:e,color:"#ffffff",transparent:!0,alphaTest:.08,depthWrite:!1,roughness:.88,metalness:0,polygonOffset:!0,polygonOffsetFactor:-2,polygonOffsetUnits:-2})}):null}function S({target:e}){return(0,o.useEffect)(()=>{if(e){let t=F();if(t)return z(e,t);let r=()=>{};return F(t=>{r=z(e,t)}),()=>r()}},[e]),null}let R="#f1d04d",C="#93a944";function q({size:e,position:t,color:r,chams:o,chamsColor:n="#4bd0e0",logo:i,children:s}){return(0,a.jsxs)("group",{position:t,children:[(0,a.jsxs)("mesh",{castShadow:!0,receiveShadow:!0,children:[(0,a.jsx)("boxGeometry",{args:e}),(0,a.jsx)("meshStandardMaterial",{color:r,roughness:.62,metalness:.06}),(0,a.jsx)(p.l,{scale:1.001,threshold:15,color:"#1a1408"}),i?(0,a.jsx)(P,{}):null]}),o?(0,a.jsxs)("mesh",{renderOrder:900,children:[(0,a.jsx)("boxGeometry",{args:e}),(0,a.jsx)("meshBasicMaterial",{color:n,transparent:!0,opacity:.35,depthTest:!0,depthWrite:!1,toneMapped:!1})]}):null,s]})}function A({bodyRef:e,idle:t=!0,chams:r=!1,chamsColor:i,children:s}){let l=(0,o.useRef)(null);return(0,n.D)(()=>{l.current&&!t&&(l.current.position.y=0,l.current.rotation.z=0,l.current.rotation.y=0)}),(0,a.jsxs)("group",{ref:l,children:[(0,a.jsxs)("group",{ref:e,children:[(0,a.jsx)(q,{size:[1.6,1.3,1.3],position:[0,1.65,0],color:"#f1d04d",chams:r,chamsColor:i}),(0,a.jsx)(q,{size:[2,2,1],position:[0,0,0],color:"#1c6ca7",chams:r,chamsColor:i,logo:!0}),(0,a.jsx)(q,{size:[1,2,1],position:[-1.5,0,0],color:R,chams:r,chamsColor:i}),(0,a.jsx)(q,{size:[1,2,1],position:[1.5,0,0],color:R,chams:r,chamsColor:i}),(0,a.jsx)(q,{size:[1,2,1],position:[-.5,-2,0],color:C,chams:r,chamsColor:i}),(0,a.jsx)(q,{size:[1,2,1],position:[.5,-2,0],color:C,chams:r,chamsColor:i})]}),s]})}let D={current:null},W="./preview-model/";function E(e){let t;return!function(e){let t=[];e.traverse(e=>{e instanceof u.eaF&&!y(e)&&t.push(e)});let r=[];for(let e of t){if(v(e.name))continue;let t=g(e),a=t.getSize(new u.Pq0);a.x<=2.6&&a.y<=11.5&&a.z<=2.6&&r.push(t)}let a=new u.NRn;r.forEach(e=>a.union(e)),a.isEmpty()&&a.setFromObject(e);let o=Math.max(.01,a.max.x-a.min.x),n=Math.max(.01,a.max.y-a.min.y),i=[];for(let e of t){if(v(e.name)){i.push(e);continue}let t=g(e),r=t.getSize(new u.Pq0),s=t.getCenter(new u.Pq0),l=e.geometry.attributes.position?.count??0;if(function(e,t,r){let a=Math.max(1.25*t,3.2),o=Math.max(1.05*t,2.4);return!!(e.x>=a)||!!(e.z>=o)&&!!(e.z>.85*e.y)||!!(e.x>=.85*r)&&!!(e.x>1.4*e.y)}(r,o,n)){i.push(e);continue}let c=r.x<=2.2&&r.z<=2.2&&r.y<=2.2;if(l>1200&&!c){i.push(e);continue}s.y>a.min.y+.82*n&&l>350&&r.y>2*r.x&&i.push(e)}for(let e of i)e.parent?.remove(e),e.geometry?.dispose(),(Array.isArray(e.material)?e.material:[e.material]).forEach(e=>e?.dispose())}(e),t=new u.NRn().setFromObject(e),e.traverse(e=>{var r;let a,o,n,i,s;if(!(e instanceof u.eaF)||y(e))return;let l=(r=g(e).getCenter(new u.Pq0),a=Math.max(.01,t.max.y-t.min.y),o=Math.max(.01,t.max.x-t.min.x),n=(r.y-t.min.y)/a,i=(t.min.x+t.max.x)*.5,s=Math.abs(r.x-i)/o,n>.78?w.head.clone():n<.4?w.legs.clone():s>.27?w.arms.clone():w.torso.clone()),c=e.material,m=Array.isArray(c)?c:[c],f=m[0],d=f&&"map"in f&&f.map instanceof u.gPd?f.map:null,p=new u._4j({map:d,color:l,roughness:.52,metalness:.05,emissive:l.clone().multiplyScalar(.06)});d&&(p.map.colorSpace=u.er$,p.map.anisotropy=4),e.material=p,m.forEach(e=>e?.dispose())}),e}function N(e){let t=new u.YJl;t.add(e);let r=new u.NRn().setFromObject(e),a=r.getCenter(new u.Pq0),o=5.2/Math.max(.001,r.getSize(new u.Pq0).y);return t.scale.setScalar(o),t.position.set(-a.x*o,-r.min.y*o+-3,-a.z*o),t.traverse(e=>{e instanceof u.eaF&&(e.castShadow=!0,e.receiveShadow=!0)}),t}function k(e){e?.traverse(e=>{e instanceof u.eaF&&(e.geometry?.dispose(),Array.isArray(e.material)?e.material.forEach(e=>e.dispose()):e.material?.dispose())})}let O=`
varying vec3 vN;
varying vec3 vW;
void main() {
  vN = normalize(normalMatrix * normal);
  vec4 w = modelViewMatrix * vec4(position, 1.0);
  vW = w.xyz;
  gl_Position = projectionMatrix * w;
}
`,T=`
uniform vec3 uColor;
uniform float uTime;
uniform float uAlpha;
uniform float uShift;
uniform int uMode;
varying vec3 vN;
varying vec3 vW;
vec3 hueRot(vec3 c, float a) {
  float cs = cos(a);
  float sn = sin(a);
  vec3 k = vec3(0.57735027);
  return clamp(c * cs + cross(k, c) * sn + k * dot(k, c) * (1.0 - cs), 0.0, 1.0);
}
vec3 pairCol(vec3 c) {
  float l = dot(c, vec3(0.299, 0.587, 0.114));
  return clamp(vec3(l) * 2.0 - c, 0.0, 1.0);
}
float hash3(vec3 p) {
  return fract(sin(dot(p, vec3(127.1, 311.7, 74.7))) * 43758.5453);
}
void main() {
  vec3 n = normalize(vN);
  vec3 v = normalize(-vW);
  float ndv = max(dot(n, v), 0.0);
  float rim = pow(1.0 - ndv, 1.45);
  vec3 user = uShift > 0.5 ? hueRot(uColor, uTime * 0.55) : uColor;
  vec3 alt = pairCol(user);
  float wires = smoothstep(0.045, 0.20, length(fwidth(n)));
  vec3 litDir = normalize(vec3(0.28, 0.94, 0.42));
  float lit = max(dot(n, litDir), 0.0);
  vec3 col = user * 0.2;
  float alpha = uAlpha;
  if (uMode == 0) {
    col = mix(user * 0.12, mix(vec3(0.75, 0.82, 0.95), user, 0.4), pow(rim, 1.3));
  } else if (uMode == 1) {
    float breath = 0.45 + 0.55 * sin(uTime * 1.7);
    col = user * (0.28 + ndv * 0.75) * breath;
  } else if (uMode == 2) {
    vec3 warm = hueRot(user, 1.15);
    float band = smoothstep(-0.25, 0.25, sin(vW.y * 1.6 + uTime * 1.25));
    col = mix(user, warm, band);
  } else if (uMode == 3) {
    col = user * pow(rim, 1.35) * 1.7;
    alpha *= 0.55 + rim * 0.45;
  } else if (uMode == 4) {
    float scan = pow(sin(vW.y * 10.0 + uTime * 2.4) * 0.5 + 0.5, 10.0);
    col = user * (0.08 + scan);
    alpha *= 0.45 + scan * 0.55;
  } else if (uMode == 5) {
    float heat = clamp(vW.y * 0.35 + 0.4, 0.0, 1.0);
    col = mix(user * vec3(0.22, 0.05, 0.02), mix(user, vec3(1.0, 0.62, 0.12), heat), heat);
  } else if (uMode == 6) {
    float band = floor(ndv * 3.0) / 3.0;
    col = user * (0.12 + band);
  } else if (uMode == 7) {
    float hair = pow(rim, 3.4);
    col = user * (0.08 + wires * 0.85 + hair * 0.35);
    alpha *= 0.28 + wires * 0.6 + hair * 0.35;
  } else if (uMode == 8) {
    col = mix(user * 0.08, vec3(0.82, 0.86, 0.92), pow(ndv, 6.0));
    col += user * pow(rim, 2.8) * 0.45;
  } else if (uMode == 9) {
    float mid = 1.0 - smoothstep(0.12, 0.55, abs(ndv - 0.42));
    col = user * (0.05 + mid);
  } else if (uMode == 10) {
    float scroll = 0.5 + 0.5 * sin(n.y * 4.0 + uTime * 0.8);
    col = mix(user * 0.2, vec3(0.75), 0.35 + scroll * 0.35);
  } else if (uMode == 11) {
    float spark = pow(hash3(floor(vW * 6.0)), 10.0);
    col = mix(user, vec3(0.82, 0.92, 1.0), 0.62) * 0.7 + vec3(0.9) * spark;
  } else if (uMode == 12) {
    col = user * pow(rim, 4.8);
    alpha *= 0.35 + rim;
  } else if (uMode == 13) {
    col = user * pow(1.0 - ndv, 0.72);
    alpha *= 0.4 + rim;
  } else if (uMode == 14) {
    float facet = floor(clamp(n.y * 0.5 + 0.5, 0.0, 1.0) * 3.0);
    col = hueRot(user, (facet - 1.0) * 0.85);
  } else if (uMode == 15) {
    float grain = hash3(floor(vW * 16.0 + uTime * 8.0));
    col = user * (0.2 + grain);
  } else if (uMode == 16) {
    float ring = pow(sin(length(vW.xz) * 4.0 - uTime * 2.1) * 0.5 + 0.5, 8.0);
    col = user * (0.1 + ring);
  } else if (uMode == 17) {
    float vein = sin(vW.x * 1.4 + sin(vW.y * 0.8) * 2.0);
    col = mix(user * 0.15, user, smoothstep(-0.15, 0.35, vein));
  } else if (uMode == 18) {
    col = user * 0.08 + hueRot(user, ndv * 5.5) * pow(rim, 0.85);
  } else if (uMode == 19) {
    col = mix(user * 0.08, user, smoothstep(0.28, 0.48, lit));
  } else if (uMode == 20) {
    float h = ndv;
    vec3 cold = user * vec3(0.15, 0.35, 1.0);
    vec3 hot = mix(user, vec3(1.0, 0.92, 0.55), 0.65);
    col = mix(cold, hot, smoothstep(0.2, 0.8, h)) * (0.35 + floor(h * 5.0) / 5.0);
  } else if (uMode == 21) {
    col = user * pow(rim, 1.15);
    alpha *= 0.25 + rim * 0.75;
  } else if (uMode == 22) {
    vec3 crack = mix(user, vec3(1.0, 0.45, 0.08), 0.55);
    col = user * vec3(0.12, 0.03, 0.02) + crack * wires;
    alpha *= 0.45 + wires * 0.55;
  } else if (uMode == 23) {
    float fringe = pow(rim, 1.15);
    float side = clamp(n.x * 1.35 + 0.5, 0.0, 1.0);
    col = mix(user * 0.18, mix(alt, user, side), fringe);
  } else if (uMode == 24) {
    float split = smoothstep(0.22, 0.7, lit);
    float seam = 1.0 - smoothstep(0.05, 0.18, abs(lit - 0.46));
    col = mix(alt, user, split) + mix(user, alt, 0.5) * seam * 0.8;
  } else {
    col = user * (0.3 + ndv);
  }
  gl_FragColor = vec4(col, alpha);
}
`;function _({bodyRef:e,idle:t=!0,chams:r=!1,chamsColor:i="#ff3355",chamsType:s=0,shaderMode:l=0,shaderAlpha:c=.88,shaderShift:p=!0,children:h}){let[x,y]=(0,o.useState)(null),[v,g]=(0,o.useState)(null),w=(0,o.useRef)(""),[M]=(0,d.Fr)("preview.avatar_status","idle"),[b]=(0,d.Fr)("preview.avatar_user_id",""),[j]=(0,d.Fr)("preview.local_user_id",""),[F]=(0,d.Fr)("preview.avatar_base_url",""),[z]=(0,d.Fr)("preview.avatar_obj_url",""),[P]=(0,d.Fr)("preview.avatar_mtl_url",""),[R]=(0,d.Fr)("preview.avatar_tex_hashes",[]);(0,o.useEffect)(()=>{let e=!1;return new Promise((e,t)=>{let r=new f.V;r.setPath(W),r.load("avatar.mtl",r=>{r.preload();let a=new m.L;a.setMaterials(r),a.load(`${W}avatar.obj`,t=>e(N(E(t))),void 0,e=>t(e))},void 0,e=>t(e))}).then(t=>{e?k(t):y(t)}).catch(()=>{e||y(null)}),()=>{e=!0}},[]),(0,o.useEffect)(()=>{if(j&&"loading"!==M){if("ready"===M&&z&&P&&b===j){w.current=j;return}(w.current!==j||"failed"!==M)&&(w.current=j,(0,d.VR)("esp_preview_avatar"))}},[j,M,b,z,P]),(0,o.useEffect)(()=>{var e;if("ready"!==M||!F||!z||!P||j&&b!==j)return;let t=!1;return(e=R??[],new Promise((t,r)=>{let a=new f.V;a.setPath(F),a.manager.setURLModifier(t=>{let r=t.split("/").pop()?.split("?")[0]??t;for(let a of e)if(t.includes(a)||r.includes(a))return`${F}${a}.png`;return t.startsWith("http://")||t.startsWith("https://")?t:F+t});let o=P.slice(F.length).split("?")[0]||"avatar.mtl",n=z.slice(F.length).split("?")[0]||"avatar.obj";a.load(o,e=>{e.preload();let a=new m.L;a.setMaterials(e),a.load(n,e=>t(N(E(e))),void 0,e=>r(e))},void 0,e=>r(e))})).then(e=>{t?k(e):g(t=>(k(t),e))}).catch(()=>{}),()=>{t=!0}},[M,F,z,P,R,b,j]);let C=v??x,q=(0,o.useRef)([]),B=(0,o.useRef)(null);return((0,o.useEffect)(()=>{var e,t,a;let o,n,m;if(q.current=[],!C||!r)return;let f=[],d=1===Number(s)?(e=Number(l)||0,t=Number(c)||.88,a=!1!==p,o=[],n=new u.Q1f(i),C.traverse(r=>{if(!(r instanceof u.eaF)||!r.geometry||r.userData.chamOverlay||r.userData.espBranding)return;let i={uColor:{value:n.clone()},uTime:{value:0},uAlpha:{value:Math.max(.2,Math.min(1,t))},uShift:{value:+!!a},uMode:{value:Math.max(0,Math.min(24,0|e))}};f.push(i.uTime);let s=new u.BKk({uniforms:i,vertexShader:O,fragmentShader:T,transparent:i.uAlpha.value<.99||3===e||4===e||7===e||12===e||13===e||21===e||22===e,depthTest:!0,depthWrite:!1,toneMapped:!1,blending:3===e||4===e||13===e||21===e?u.EZo:u.NTi}),l=new u.eaF(r.geometry,s);l.renderOrder=910,l.userData.chamOverlay=!0,l.position.copy(r.position),l.rotation.copy(r.rotation),l.scale.copy(r.scale),r.parent?.add(l),o.push(l)}),()=>{o.forEach(e=>{e.removeFromParent(),e.material instanceof u.imn&&e.material.dispose()})}):(m=[],C.traverse(e=>{if(!(e instanceof u.eaF)||!e.geometry||e.userData.chamOverlay||e.userData.espBranding)return;let t=new u.V9B({color:i,transparent:!0,opacity:.35,depthTest:!0,depthWrite:!1,toneMapped:!1}),r=new u.eaF(e.geometry,t);r.renderOrder=900,r.userData.chamOverlay=!0,r.position.copy(e.position),r.rotation.copy(e.rotation),r.scale.copy(e.scale),e.parent?.add(r),m.push(r)}),()=>{m.forEach(e=>{e.removeFromParent(),e.material instanceof u.imn&&e.material.dispose()})});return q.current=f,()=>{q.current=[],d?.()}},[C,r,i,s,l,c,p]),(0,n.D)((e,r)=>{for(let e of q.current)"number"==typeof e.value&&(e.value+=r);B.current&&!t&&C&&(B.current.position.y=0)}),C||"failed"!==M)?C?(0,a.jsx)("group",{ref:e,children:(0,a.jsxs)("group",{ref:B,children:[(0,a.jsx)("primitive",{object:C}),(0,a.jsx)(S,{target:C})]})}):(0,a.jsx)("group",{ref:e}):(0,a.jsx)("group",{ref:e,children:(0,a.jsx)(A,{bodyRef:D,idle:t,chams:r,chamsColor:i,children:h})})}function B(e,t,r,a){t.makeEmpty(),e.updateMatrixWorld(!0),e.traverse(e=>{if(!(e instanceof u.eaF)||!e.geometry||e.userData.chamOverlay||e.userData.espBranding)return;e.geometry.boundingBox||e.geometry.computeBoundingBox();let o=e.geometry.boundingBox;!o||o.isEmpty()||(r.copy(o).applyMatrix4(e.matrixWorld),r.getSize(a),a.x>2.35&&a.y<.6*a.x||a.z>2.2&&a.y<.7*a.z||t.union(r))})}function L({bodyRef:e,hud:t}){let r=(0,n.C)(e=>e.camera),a=(0,n.C)(e=>e.size),i=(0,o.useMemo)(()=>new u.NRn,[]),s=(0,o.useMemo)(()=>new u.NRn,[]),l=(0,o.useMemo)(()=>new u.Pq0,[]),c=(0,o.useMemo)(()=>new u.Pq0,[]),m=(0,o.useMemo)(()=>new u.Pq0,[]);return(0,n.D)(()=>{let o=e.current,n=t.current;if(!o||!n?.frame)return;if(B(o,i,s,l),i.isEmpty()||!Number.isFinite(i.min.x)||i.max.y-i.min.y<.05){n.frame.style.opacity="0",n.tracer&&(n.tracer.style.opacity="0");return}i.getCenter(m);let u=1/0,f=1/0,d=-1/0,p=-1/0,h=!0;for(let e=0;e<8;e++){c.set(1&e?i.max.x:i.min.x,2&e?i.max.y:i.min.y,4&e?i.max.z:i.min.z),c.project(r),c.z>1&&(h=!1);let t=(.5*c.x+.5)*a.width,o=(-(.5*c.y)+.5)*a.height;u=Math.min(u,t),d=Math.max(d,t),f=Math.min(f,o),p=Math.max(p,o)}let x=d-u,y=p-f;n.frame.style.opacity=h?"1":"0",n.frame.style.transform=`translate3d(${u.toFixed(1)}px, ${f.toFixed(1)}px, 0)`,n.frame.style.width=`${x.toFixed(1)}px`,n.frame.style.height=`${y.toFixed(1)}px`,n.dist&&(n.dist.textContent=r.position.distanceTo(m).toFixed(1)),n.tracer&&(n.tracer.setAttribute("x2",(u+x/2).toFixed(1)),n.tracer.setAttribute("y2",p.toFixed(1)),n.tracer.style.opacity=h?"1":"0")}),null}function $(e){let t=Math.max(.01,e.max.y-e.min.y),r=Math.max(.01,e.max.x-e.min.x),a=e.min.y+.015*t,o=e.max.y-.09*t,n=e.min.x+.18*r,i=e.max.x-.18*r,s=Math.max(.01,o-a),l=Math.max(.01,i-n),c=(n+i)*.5,m=(e.min.z+e.max.z)*.5,f=new u.Pq0(c,a+.91*s,m),d=new u.Pq0(c,a+.8*s,m),p=new u.Pq0(c,a+.47*s,m),h=new u.Pq0(c-.38*l,a+.77*s,m),x=new u.Pq0(c+.38*l,a+.77*s,m);return[[f,d],[d,p],[d,h],[h,new u.Pq0(c-.46*l,a+.46*s,m)],[d,x],[x,new u.Pq0(c+.46*l,a+.46*s,m)],[p,new u.Pq0(c-.16*l,a+.03*s,m)],[p,new u.Pq0(c+.16*l,a+.03*s,m)]]}function G({bodyRef:e,enabled:t,color:r}){let i=(0,o.useMemo)(()=>new Float32Array(48),[]),s=(0,o.useMemo)(()=>{let e=new u.LoY;return e.setAttribute("position",new u.THS(i,3)),e.setDrawRange(0,0),e},[i]),l=(0,o.useMemo)(()=>new u.NRn,[]),c=(0,o.useMemo)(()=>new u.NRn,[]),m=(0,o.useMemo)(()=>new u.Pq0,[]);return((0,n.D)(()=>{let r=e.current;if(!t||!r||(B(r,l,c,m),l.isEmpty()||l.max.y-l.min.y<.05))return void s.setDrawRange(0,0);let a=$(l),o=0;for(let[e,t]of a)i[o++]=e.x,i[o++]=e.y,i[o++]=e.z,i[o++]=t.x,i[o++]=t.y,i[o++]=t.z;s.getAttribute("position").needsUpdate=!0,s.setDrawRange(0,2*a.length),s.computeBoundingSphere()}),t)?(0,a.jsx)("lineSegments",{geometry:s,frustumCulled:!1,renderOrder:2e3,children:(0,a.jsx)("lineBasicMaterial",{color:r,depthTest:!1,depthWrite:!1,transparent:!0,opacity:.95,toneMapped:!1})}):null}function I({bodyRef:e,hud:t,enabled:r,headDot:a}){let i=(0,n.C)(e=>e.camera),s=(0,n.C)(e=>e.size),l=(0,o.useMemo)(()=>new u.Pq0,[]),c=(0,o.useMemo)(()=>new u.NRn,[]),m=(0,o.useMemo)(()=>new u.NRn,[]),f=(0,o.useMemo)(()=>new u.Pq0,[]);return(0,n.D)(()=>{let o=t.current?.skeletonLines,n=t.current?.headDot,u=e.current;if(!u||!r&&!a||(B(u,c,m,f),c.isEmpty())){o?.forEach(e=>{e&&(e.style.opacity="0")}),n&&(n.style.opacity="0");return}let d=$(c);if(r&&o?.length)for(let e=0;e<o.length;e++){let t=o[e];if(!t)continue;if(e>=d.length){t.style.opacity="0";continue}let[r,a]=d[e],n=!0;l.copy(r),l.project(i),l.z>1&&(n=!1);let c=(.5*l.x+.5)*s.width,u=(-(.5*l.y)+.5)*s.height;l.copy(a),l.project(i),l.z>1&&(n=!1);let m=(.5*l.x+.5)*s.width,f=(-(.5*l.y)+.5)*s.height;t.setAttribute("x1",c.toFixed(1)),t.setAttribute("y1",u.toFixed(1)),t.setAttribute("x2",m.toFixed(1)),t.setAttribute("y2",f.toFixed(1)),t.setAttribute("stroke-opacity",n?"0.95":"0"),t.style.opacity=n?"1":"0"}else o?.forEach(e=>{e&&(e.style.opacity="0")});if(a&&n){let e=d[0][0];l.copy(e),l.project(i);let t=l.z<=1,r=(.5*l.x+.5)*s.width,a=(-(.5*l.y)+.5)*s.height;n.setAttribute("cx",r.toFixed(1)),n.setAttribute("cy",a.toFixed(1)),n.setAttribute("r","4"),n.style.opacity=t?"1":"0"}else n&&(n.style.opacity="0")}),null}function Q(){return(0,a.jsxs)("group",{children:[(0,a.jsx)(s.x,{position:[0,.01,0],args:[24,24],cellSize:1,cellThickness:.4,cellColor:"#243343",sectionSize:4,sectionThickness:.8,sectionColor:"#31586b",fadeDistance:22,fadeStrength:1.2,infiniteGrid:!0}),(0,a.jsxs)("mesh",{rotation:[-Math.PI/2,0,0],receiveShadow:!0,children:[(0,a.jsx)("planeGeometry",{args:[40,40]}),(0,a.jsx)("meshStandardMaterial",{color:"#161c25",roughness:.95,metalness:0})]})]})}let U=new u.Pq0(0,2.6,0);function V(){let e=(0,o.useRef)(null),{camera:t}=(0,n.C)();return(0,o.useLayoutEffect)(()=>{let r=new u.Pq0(.85,.22,1).normalize();t.position.copy(U).add(r.multiplyScalar(12)),t.lookAt(U),t.updateProjectionMatrix();let a=e.current;a&&(a.target.copy(U),a.update())},[t]),(0,a.jsx)(l.N,{ref:e,makeDefault:!0,target:[U.x,U.y,U.z],enablePan:!1,minDistance:5,maxDistance:12,minPolarAngle:.3,maxPolarAngle:Math.PI/2.05,enableDamping:!0,dampingFactor:.1,rotateSpeed:.65})}function H({options:e,hud:t}){let r=(0,o.useRef)(null);return(0,a.jsxs)(i.Hl,{shadows:!0,dpr:[1,1.5],camera:{position:[10.2,5.2,12],fov:42},gl:{antialias:!0,alpha:!1},style:{width:"100%",height:"100%",display:"block"},children:[(0,a.jsx)("color",{attach:"background",args:["#14181f"]}),(0,a.jsx)("fog",{attach:"fog",args:["#14181f",18,42]}),(0,a.jsx)("ambientLight",{intensity:.5}),(0,a.jsx)("hemisphereLight",{args:["#8fd7e8","#0e1218",.45]}),(0,a.jsx)("directionalLight",{position:[5,9,4],intensity:1.4,castShadow:!0,"shadow-mapSize":[512,512],"shadow-camera-left":-10,"shadow-camera-right":10,"shadow-camera-top":10,"shadow-camera-bottom":-10}),(0,a.jsx)(Q,{}),(0,a.jsx)(c._,{position:[0,.02,0],opacity:.38,scale:14,blur:2,far:6}),(0,a.jsx)("group",{position:[0,3,0],children:(0,a.jsx)(_,{bodyRef:r,idle:e.idle,chams:e.chams,chamsColor:e.chamsColor,chamsType:e.chamsType??0,shaderMode:e.shaderMode??0,shaderAlpha:e.shaderAlpha??.88,shaderShift:e.shaderShift??!0})}),(0,a.jsx)(L,{bodyRef:r,hud:t}),(0,a.jsx)(G,{bodyRef:r,enabled:e.skeleton,color:e.skeletonColor}),(0,a.jsx)(I,{bodyRef:r,hud:t,enabled:e.skeleton,headDot:e.headDot}),(0,a.jsx)(V,{})]})}}}]);